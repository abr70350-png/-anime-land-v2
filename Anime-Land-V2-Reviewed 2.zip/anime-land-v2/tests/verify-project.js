const fs = require('fs');
const path = require('path');
const assert = require('assert');

// 1. فحص اكتمال جميع الملفات الأساسية
const requiredFiles = [
  'package.json',
  'tsconfig.json',
  'next.config.mjs',
  'prisma/schema.prisma',
  'prisma/seed.js',
  'public/manifest.json',
  'public/sw.js',
  'public/icon.svg',
  'src/app/layout.tsx',
  'src/app/page.tsx',
  'src/app/library/page.tsx',
  'src/app/anime/[slug]/page.tsx',
  'src/app/watch/[slug]/[episodeId]/page.tsx',
  'src/app/auth/page.tsx',
  'src/app/profile/page.tsx',
  'src/app/admin/page.tsx',
  'src/app/api/auth/login/route.ts',
  'src/app/api/auth/register/route.ts',
  'src/app/api/favorites/route.ts',
  'src/app/api/watch-history/route.ts',
  'src/app/api/episodes/route.ts',
];

for (const file of requiredFiles) {
  const full = path.join(__dirname, '..', file);
  assert(fs.existsSync(full), `الملف المفقود: ${file}`);
}

const schema = fs.readFileSync(path.join(__dirname, '..', 'prisma/schema.prisma'), 'utf8');
assert(schema.includes('provider = "postgresql"'), 'يجب أن يكون موفر قاعدة البيانات postgresql');

const manifest = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'public/manifest.json'), 'utf8'));
assert.strictEqual(manifest.display, 'standalone', 'يجب أن يدعم manifest التثبيت المستقل على iPhone');
assert(fs.existsSync(path.join(__dirname, '..', 'public/icon.svg')), 'أيقونة PWA مفقودة');
const auth = fs.readFileSync(path.join(__dirname, '..', 'src/lib/auth.ts'), 'utf8');
assert(auth.includes('JWT_SECRET must be configured'), 'يجب رفض سر JWT الافتراضي');
const config = fs.readFileSync(path.join(__dirname, '..', 'next.config.mjs'), 'utf8');
assert(!config.includes('Access-Control-Allow-Origin'), 'لا تسمح CORS wildcard مع جلسات الدخول');
const seed = fs.readFileSync(path.join(__dirname, '..', 'prisma/seed.js'), 'utf8');
assert(!seed.includes('Admin@123456') && !seed.includes('User@123456'), 'يجب عدم إنشاء حسابات بكلمات مرور افتراضية');

console.log('✓ اجتازت الملفات الأساسية وفحوصات الإعداد والأمان الساكنة. هذا لا يغني عن تثبيت الحزم وتشغيل build واختبار قاعدة البيانات.');

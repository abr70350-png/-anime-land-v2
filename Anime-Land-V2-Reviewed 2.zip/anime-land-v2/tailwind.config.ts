import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          bg: "#090B10",
          surface: "#121622",
          card: "#181E2E",
          border: "#262F45",
          primary: "#6366F1",
          primaryHover: "#4F46E5",
          accent: "#EC4899",
          gold: "#F59E0B",
        },
      },
      fontFamily: {
        arabic: ["var(--font-cairo)", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
export default config;

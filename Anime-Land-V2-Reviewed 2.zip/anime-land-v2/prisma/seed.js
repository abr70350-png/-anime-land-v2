const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

const LICENSED_STREAMS = {
  tearsOfSteel: JSON.stringify({
    "1080p": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
    "720p": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
    "480p": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
  }),
  sintel: JSON.stringify({
    "1080p": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
    "720p": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
    "480p": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"
  }),
  elephantsDream: JSON.stringify({
    "1080p": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    "720p": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    "480p": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4"
  })
};

async function main() {
  console.log('بدء تهيئة قاعدة بيانات PostgreSQL لمنصة Anime Land...');

  // لا تُنشأ حسابات افتراضية بكلمات مرور معروفة. أنشئ المشرف فقط
  // عند توفير بيانات اعتماد قوية عبر متغيرات البيئة.
  const adminEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const adminPassword = process.env.ADMIN_PASSWORD;
  if (adminEmail && adminPassword) {
    if (adminPassword.length < 16) {
      throw new Error('ADMIN_PASSWORD must contain at least 16 characters.');
    }
    const passwordHash = await bcrypt.hash(adminPassword, 12);
    await prisma.user.upsert({
      where: { email: adminEmail },
      update: { passwordHash, role: 'ADMIN' },
      create: {
        username: process.env.ADMIN_USERNAME || 'مدير_النظام',
        email: adminEmail,
        passwordHash,
        role: 'ADMIN',
        avatarUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b13701-565224242.png',
        bio: 'المشرف العام على منصة Anime Land.'
      }
    });
  } else {
    console.log('لم يتم إنشاء حساب مشرف: عيّن ADMIN_EMAIL و ADMIN_PASSWORD لإنشائه بأمان.');
  }

  const animesData = [
    {
      slug: 'moriarty-the-patriot',
      titleAr: 'موريارتي الوطني',
      titleEn: 'Moriarty the Patriot',
      titleJp: '憂国のモリアーティ',
      synopsisAr: 'في أواخر القرن التاسع عشر، تهيمن الإمبراطورية البريطانية على العالم بنظام طبقي صارم. يقرر الشاب العبقري ويليام جيمس موريارتي تحطيم هذا النظام الفاسد من الجذور مستخدماً ذكاءه الاستراتيجي الفذ ليصبح مستشار الجريمة الأول في لندن، في مواجهة فكرية مع المحقق الأسطوري شيرلوك هولمز.',
      coverImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx114124-614231072.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/114124-794769260.jpg',
      releaseYear: 2020,
      season: 'خريف',
      status: 'مكتمل',
      ageRating: '+16',
      seasonsCount: 2,
      episodesCount: 24,
      viewsCount: 184500,
      avgRating: 9.2,
      ratingCount: 4120,
      studio: 'Production I.G',
      licenseSource: 'AniList Public API + Licensed CC Stream',
      isTrending: true,
      isFeatured: true,
      genres: 'غموض,أكشن,دراما,نفسي',
      characters: [
        { nameAr: 'ويليام جيمس موريارتي', nameJp: 'ウィリアム・ジェームズ・モリアーティ', role: 'شخصية رئيسية', imageUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b13701-565224242.png', voiceActor: 'سوما سايتو' },
        { nameAr: 'شيرلوك هولمز', nameJp: 'シャーロック・ホームズ', role: 'شخصية رئيسية', imageUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b13702-92140192.png', voiceActor: 'ماكوتو فوروكاوا' },
        { nameAr: 'ألبرت جيمس موريارتي', nameJp: 'アルバート・ジェームズ・モリアーティ', role: 'شخصية رئيسية', imageUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b13703-112345.png', voiceActor: 'تاكويا ساتو' }
      ],
      episodes: [
        { seasonNumber: 1, episodeNumber: 1, titleAr: 'جريمة الإيرل', durationSec: 734, thumbnailUrl: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/114124-794769260.jpg', videoSources: LICENSED_STREAMS.tearsOfSteel },
        { seasonNumber: 1, episodeNumber: 2, titleAr: 'العيون القرمزية - الفصل الأول', durationSec: 888, thumbnailUrl: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx114124-614231072.jpg', videoSources: LICENSED_STREAMS.sintel },
        { seasonNumber: 1, episodeNumber: 3, titleAr: 'العيون القرمزية - الفصل الثاني', durationSec: 653, thumbnailUrl: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/114124-794769260.jpg', videoSources: LICENSED_STREAMS.elephantsDream }
      ]
    },
    {
      slug: 'hunter-x-hunter',
      titleAr: 'القناص',
      titleEn: 'Hunter x Hunter (2011)',
      titleJp: 'HUNTER×HUNTER',
      synopsisAr: 'ينطلق الفتى الصغير غون فريكس في رحلة محفوفة بالمخاطر ليصبح صياداً محترفاً على خطى والده المفقود. خلال رحلته يلتقي بأصدقاء أوفياء مثل كيلوا وكورابيكا وليوريو، ويواجهون اختبارات قاسية وعوالم مليئة بالقدرات الخارقة (النين) والمنظمات الغامضة.',
      coverImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx11061-sIpBprNRfzCe.png',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/11061-8WkkNSXkroot.jpg',
      releaseYear: 2011,
      season: 'خريف',
      status: 'مكتمل',
      ageRating: '+13',
      seasonsCount: 6,
      episodesCount: 148,
      viewsCount: 392000,
      avgRating: 9.5,
      ratingCount: 9850,
      studio: 'Madhouse',
      licenseSource: 'AniList Public API + Licensed CC Stream',
      isTrending: true,
      isFeatured: true,
      genres: 'أكشن,مغامرات,فانتازيا',
      characters: [
        { nameAr: 'غون فريكس', nameJp: 'ゴン＝フリークス', role: 'شخصية رئيسية', imageUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b30-2854192.png', voiceActor: 'ميغومي هان' },
        { nameAr: 'كيلوا زولديك', nameJp: 'キルア＝ゾルディック', role: 'شخصية رئيسية', imageUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b27-Z5t5123.png', voiceActor: 'ماريا إيسي' },
        { nameAr: 'كورابيكا', nameJp: 'クラピカ', role: 'شخصية رئيسية', imageUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b28-123987.png', voiceActor: 'ميوكي ساواشيرو' }
      ],
      episodes: [
        { seasonNumber: 1, episodeNumber: 1, titleAr: 'انطلاق × و × أصدقاء', durationSec: 888, thumbnailUrl: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/11061-8WkkNSXkroot.jpg', videoSources: LICENSED_STREAMS.sintel },
        { seasonNumber: 1, episodeNumber: 2, titleAr: 'اختبار × الـ × اختبارات', durationSec: 734, thumbnailUrl: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx11061-sIpBprNRfzCe.png', videoSources: LICENSED_STREAMS.tearsOfSteel }
      ]
    },
    {
      slug: 'frieren-beyond-journeys-end',
      titleAr: 'فريرين: ما بعد نهاية الرحلة',
      titleEn: 'Frieren: Beyond Journey’s End',
      titleJp: '葬送のフリーレン',
      synopsisAr: 'بعد عشر سنوات من المغامرة وهزيمة ملك الشياطين، تعود الساحرة الجنية فريرين إلى العاصمة. لكن مرور الزمن يختلف بالنسبة لها عن رفاقها البشر؛ فتبدأ رحلة جديدة لفهم مشاعر البشر ومعنى الروابط التي جمعتها بأصدقائها القدامى.',
      coverImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx154587-n1fmjVj4VyVN.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/154587-ivXNJ23SM1xB.jpg',
      releaseYear: 2023,
      season: 'خريف',
      status: 'مستمر',
      ageRating: '+13',
      seasonsCount: 2,
      episodesCount: 28,
      viewsCount: 276400,
      avgRating: 9.6,
      ratingCount: 7430,
      studio: 'Madhouse',
      licenseSource: 'AniList Public API + Licensed CC Stream',
      isTrending: true,
      isFeatured: false,
      genres: 'مغامرات,دراما,فانتازيا',
      characters: [
        { nameAr: 'فريرين', nameJp: 'フリーレン', role: 'شخصية رئيسية', imageUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b176754-PC123.png', voiceActor: 'أتسومي تانيزاكي' },
        { nameAr: 'فيرن', nameJp: 'フェルン', role: 'شخصية رئيسية', imageUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b183965-AB123.png', voiceActor: 'كانا إيتشينوسي' }
      ],
      episodes: [
        { seasonNumber: 1, episodeNumber: 1, titleAr: 'نهاية المغامرة', durationSec: 888, thumbnailUrl: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/154587-ivXNJ23SM1xB.jpg', videoSources: LICENSED_STREAMS.sintel },
        { seasonNumber: 1, episodeNumber: 2, titleAr: 'لم يكن الأمر بحاجة للسحر', durationSec: 653, thumbnailUrl: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx154587-n1fmjVj4VyVN.jpg', videoSources: LICENSED_STREAMS.elephantsDream }
      ]
    },
    {
      slug: 'haikyuu',
      titleAr: 'هايكيو!!',
      titleEn: 'Haikyu!!',
      titleJp: 'ハイキュー!!',
      synopsisAr: 'يستلهم شويو هيناتا شغفه بالكرة الطائرة بعد مشاهدته للاعب قصير القامة يُلقب بالعملاق الصغير. ينضم إلى فريق مدرسة كاراسونو الثانوية ليجد نفسه زميلاً لمنافسه اللدود توبيو كاغياما، ويسعيان معاً لإعادة أمجاد الفريق إلى البطولة الوطنية.',
      coverImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx20464-eW7ZDBOej74a.png',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/20464-7341239.jpg',
      releaseYear: 2014,
      season: 'ربيع',
      status: 'مكتمل',
      ageRating: 'عائلي',
      seasonsCount: 4,
      episodesCount: 85,
      viewsCount: 215000,
      avgRating: 9.1,
      ratingCount: 6200,
      studio: 'Production I.G',
      licenseSource: 'AniList Public API + Licensed CC Stream',
      isTrending: false,
      isFeatured: false,
      genres: 'رياضة,كوميديا,دراما',
      characters: [
        { nameAr: 'شويو هيناتا', nameJp: '日向 翔陽', role: 'شخصية رئيسية', imageUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b64769-123.png', voiceActor: 'أيومو موراسي' },
        { nameAr: 'توبيو كاغياما', nameJp: '影山 飛雄', role: 'شخصية رئيسية', imageUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b64771-456.png', voiceActor: 'كايتو إيشيكاوا' }
      ],
      episodes: [
        { seasonNumber: 1, episodeNumber: 1, titleAr: 'النهاية والبداية', durationSec: 734, thumbnailUrl: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx20464-eW7ZDBOej74a.png', videoSources: LICENSED_STREAMS.tearsOfSteel }
      ]
    },
    {
      slug: 'spy-x-family',
      titleAr: 'سباي إكس فاميلي',
      titleEn: 'SPY x FAMILY',
      titleJp: 'スパイファミリー',
      synopsisAr: 'للحفاظ على السلام الهش بين دولتين متنافستين، يُكلَّف الجاسوس الأسطوري "الشفق" بتكوين عائلة مزيفة للتسلل إلى مدرسة نخبوية. دون علمه، يتبنى فتاة تقرأ الأفكار ويتزوج قاتلة مأجورة محترفة، في مزيج يجمع الأكشن بالكوميديا العائلية.',
      coverImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx140960-vN39AmOWrVB5.jpg',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/140960-Z7x5123.jpg',
      releaseYear: 2022,
      season: 'ربيع',
      status: 'مستمر',
      ageRating: '+13',
      seasonsCount: 2,
      episodesCount: 37,
      viewsCount: 310200,
      avgRating: 8.9,
      ratingCount: 8100,
      studio: 'WIT STUDIO × CloverWorks',
      licenseSource: 'AniList Public API + Licensed CC Stream',
      isTrending: true,
      isFeatured: false,
      genres: 'كوميديا,أكشن,رومانسي',
      characters: [
        { nameAr: 'لويد فورجر', nameJp: 'ロイド・フォージャー', role: 'شخصية رئيسية', imageUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b138101-123.png', voiceActor: 'تاكويا إيغوتشي' },
        { nameAr: 'آنيا فورجر', nameJp: 'アーニャ・フォージャー', role: 'شخصية رئيسية', imageUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b138102-123.png', voiceActor: 'أتسومي تانيزاكي' }
      ],
      episodes: [
        { seasonNumber: 1, episodeNumber: 1, titleAr: 'عملية ستريكس', durationSec: 653, thumbnailUrl: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx140960-vN39AmOWrVB5.jpg', videoSources: LICENSED_STREAMS.elephantsDream }
      ]
    },
    {
      slug: 'your-name',
      titleAr: 'اسمك (كيمي نو نا وا)',
      titleEn: 'Your Name.',
      titleJp: '君の名は。',
      synopsisAr: 'ميتسوها فتاة تعيش في بلدة ريفية هادئة وتطمح لحياة المدينة، وتاكي شاب يعيش في طوكيو الصاخبة. يستيقظ الاثنان ليجدا أنهما يتبادلان الأجساد بشكل غامض في أحلامهما، لتبدأ رحلة بحث تتجاوز حدود المكان والزمان.',
      coverImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx21519-XIr3PgjUJrFi.png',
      bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/21519-12345.jpg',
      releaseYear: 2016,
      season: 'صيف',
      status: 'مكتمل',
      ageRating: '+13',
      seasonsCount: 1,
      episodesCount: 1,
      viewsCount: 410000,
      avgRating: 9.4,
      ratingCount: 11200,
      studio: 'CoMix Wave Films',
      licenseSource: 'AniList Public API + Licensed CC Stream',
      isTrending: false,
      isFeatured: false,
      genres: 'رومانسي,دراما,غموض',
      characters: [
        { nameAr: 'ميتسوها مياميزو', nameJp: '宮水 三葉', role: 'شخصية رئيسية', imageUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b88748-123.png', voiceActor: 'موني كاميشيرايشي' },
        { nameAr: 'تاكي تاتشيبانا', nameJp: '立花 瀧', role: 'شخصية رئيسية', imageUrl: 'https://s4.anilist.co/file/anilistcdn/character/large/b88747-123.png', voiceActor: 'ريونوسوكي كاميكي' }
      ],
      episodes: [
        { seasonNumber: 1, episodeNumber: 1, titleAr: 'الفيلم الكامل (نسخة العرض المرخصة)', durationSec: 888, thumbnailUrl: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx21519-XIr3PgjUJrFi.png', videoSources: LICENSED_STREAMS.sintel }
      ]
    }
  ];

  for (const item of animesData) {
    const { characters, episodes, ...animeFields } = item;
    const createdAnime = await prisma.anime.upsert({
      where: { slug: animeFields.slug },
      update: animeFields,
      create: {
        ...animeFields,
        characters: { create: characters },
        episodes: { create: episodes }
      }
    });

  }

  console.log('تمت تهيئة قاعدة بيانات PostgreSQL بنجاح!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

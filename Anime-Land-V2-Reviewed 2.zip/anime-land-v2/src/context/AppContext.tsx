'use client';

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

export interface UserProfile {
  id: string;
  username: string;
  email: string;
  avatarUrl: string;
  role: 'USER' | 'ADMIN';
  bio?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  link: string;
  isRead: boolean;
  createdAt: string;
}

interface AppContextType {
  user: UserProfile | null;
  favorites: any[];
  subscribedAnimeIds: string[];
  watchHistory: any[];
  notifications: NotificationItem[];
  loadingAuth: boolean;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  refreshUserData: () => Promise<void>;
  logout: () => Promise<void>;
  markNotificationsRead: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [favorites, setFavorites] = useState<any[]>([]);
  const [subscribedAnimeIds, setSubscribedAnimeIds] = useState<string[]>([]);
  const [watchHistory, setWatchHistory] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loadingAuth, setLoadingAuth] = useState(true);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  useEffect(() => {
    const savedTheme = localStorage.getItem('animeland_theme') as 'dark' | 'light' | null;
    if (savedTheme) {
      setTheme(savedTheme);
      document.documentElement.classList.toggle('dark', savedTheme === 'dark');
    } else {
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    localStorage.setItem('animeland_theme', next);
    document.documentElement.classList.toggle('dark', next === 'dark');
  };

  const refreshUserData = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/me', { cache: 'no-store' });
      const data = await res.json();
      setUser(data.user || null);
      setFavorites(data.favorites || []);
      setSubscribedAnimeIds(data.subscribedAnimeIds || []);
      setWatchHistory(data.watchHistory || []);
      setNotifications(data.notifications || []);
    } catch {
      setUser(null);
    } finally {
      setLoadingAuth(false);
    }
  }, []);

  useEffect(() => {
    refreshUserData();
  }, [refreshUserData]);

  const logout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    setUser(null);
    setFavorites([]);
    setSubscribedAnimeIds([]);
    setWatchHistory([]);
    setNotifications([]);
  };

  const markNotificationsRead = async () => {
    await fetch('/api/notifications', { method: 'PATCH' });
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  return (
    <AppContext.Provider
      value={{
        user,
        favorites,
        subscribedAnimeIds,
        watchHistory,
        notifications,
        loadingAuth,
        theme,
        toggleTheme,
        refreshUserData,
        logout,
        markNotificationsRead,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}

'use client';

import React, { useRef, useState, useEffect } from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Settings,
  SkipForward,
  SkipBack,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';

interface VideoPlayerProps {
  episodeId: string;
  titleAr: string;
  episodeNumber: number;
  videoSources: Record<string, string>;
  licenseProvider: string;
  initialProgress?: number;
  hasNext?: boolean;
  hasPrev?: boolean;
  onNext?: () => void;
  onPrev?: () => void;
}

export default function VideoPlayer({
  episodeId,
  titleAr,
  episodeNumber,
  videoSources,
  licenseProvider,
  initialProgress = 0,
  hasNext,
  hasPrev,
  onNext,
  onPrev,
}: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const qualities = Object.keys(videoSources);
  const [selectedQuality, setSelectedQuality] = useState<string>(qualities[0] || '1080p');
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(initialProgress);
  const [duration, setDuration] = useState(0);
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);
  const lastSavedRef = useRef<number>(initialProgress);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const handleLoaded = () => {
      setDuration(video.duration || 0);
      if (initialProgress > 2 && initialProgress < (video.duration || 9999) - 5) {
        video.currentTime = initialProgress;
      }
    };
    video.addEventListener('loadedmetadata', handleLoaded);
    return () => video.removeEventListener('loadedmetadata', handleLoaded);
  }, [episodeId, initialProgress]);

  const saveProgress = async (time: number, dur: number) => {
    if (Math.abs(time - lastSavedRef.current) < 8) return;
    lastSavedRef.current = time;
    try {
      const res = await fetch('/api/watch-history', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          episodeId,
          progressSeconds: Math.floor(time),
          durationSeconds: Math.floor(dur || 1440),
        }),
      });
      const data = await res.json();
      if (data.saved) {
        setSavedNotice(true);
        setTimeout(() => setSavedNotice(false), 2000);
      }
    } catch {}
  };

  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (!video) return;
    setCurrentTime(video.currentTime);
    setDuration(video.duration || 0);
    saveProgress(video.currentTime, video.duration);
  };

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.play();
      setIsPlaying(true);
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  const handleQualityChange = (q: string) => {
    const video = videoRef.current;
    const resumeTime = video ? video.currentTime : currentTime;
    const wasPlaying = video ? !video.paused : false;
    setSelectedQuality(q);
    setShowQualityMenu(false);

    setTimeout(() => {
      if (videoRef.current) {
        videoRef.current.currentTime = resumeTime;
        if (wasPlaying) videoRef.current.play();
      }
    }, 50);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = val;
    }
    setCurrentTime(val);
  };

  const toggleFullscreen = () => {
    const video = videoRef.current as any;
    const container = video?.parentElement as any;
    if (video?.webkitEnterFullscreen) {
      video.webkitEnterFullscreen();
    } else if (!document.fullscreenElement) {
      container?.requestFullscreen?.();
    } else {
      document.exitFullscreen?.();
    }
  };

  const formatTime = (sec: number) => {
    if (!sec || isNaN(sec)) return '00:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  return (
    <div className="rounded-2xl overflow-hidden bg-black border border-brand-border shadow-2xl">
      <div className="bg-brand-surface px-4 py-2.5 flex items-center justify-between border-b border-brand-border text-xs">
        <div className="flex items-center gap-2 text-emerald-400 font-semibold">
          <ShieldCheck className="w-4 h-4" />
          <span>بث مرخص رسمياً: {licenseProvider}</span>
        </div>
        <div className="flex items-center gap-3">
          {savedNotice && (
            <span className="flex items-center gap-1 text-brand-primary animate-pulse">
              <CheckCircle2 className="w-3.5 h-3.5" />
              تم حفظ نقطة المشاهدة
            </span>
          )}
          <span className="px-2 py-0.5 rounded bg-brand-primary/20 text-brand-primary font-bold">
            جودة {selectedQuality}
          </span>
        </div>
      </div>

      <div className="relative aspect-video w-full bg-black group">
        <video
          ref={videoRef}
          src={videoSources[selectedQuality]}
          onClick={togglePlay}
          onTimeUpdate={handleTimeUpdate}
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          playsInline
          webkit-playsinline="true"
          className="w-full h-full object-contain cursor-pointer"
        />

        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/95 via-black/70 to-transparent p-4 space-y-2.5">
          <input
            type="range"
            min={0}
            max={duration || 100}
            value={currentTime}
            onChange={handleSeek}
            className="w-full accent-brand-primary h-1.5 bg-white/25 rounded-lg cursor-pointer"
          />

          <div className="flex items-center justify-between text-white text-xs">
            <div className="flex items-center gap-3">
              <button
                onClick={togglePlay}
                className="p-2 rounded-xl bg-brand-primary hover:bg-brand-primaryHover transition"
                aria-label="تشغيل أو إيقاف"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
              </button>

              {hasPrev && (
                <button
                  onClick={onPrev}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 transition"
                >
                  <SkipForward className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">السابقة</span>
                </button>
              )}

              {hasNext && (
                <button
                  onClick={onNext}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 transition"
                >
                  <span className="hidden sm:inline">التالية</span>
                  <SkipBack className="w-3.5 h-3.5" />
                </button>
              )}

              <button
                onClick={() => {
                  if (videoRef.current) {
                    videoRef.current.muted = !isMuted;
                    setIsMuted(!isMuted);
                  }
                }}
                className="p-1.5 rounded-lg hover:bg-white/10 transition"
              >
                {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
              </button>

              <span className="font-mono text-[11px] text-slate-300">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>
            </div>

            <div className="flex items-center gap-2 relative">
              <span className="hidden md:inline text-slate-300 font-semibold ml-2">
                الحلقة {episodeNumber}: {titleAr}
              </span>

              <div className="relative">
                <button
                  onClick={() => setShowQualityMenu(!showQualityMenu)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 font-bold transition"
                >
                  <Settings className="w-3.5 h-3.5" />
                  <span>{selectedQuality}</span>
                </button>

                {showQualityMenu && (
                  <div className="absolute bottom-10 left-0 bg-brand-surface border border-brand-border rounded-xl p-1.5 shadow-xl min-w-[110px] z-30">
                    {qualities.map((q) => (
                      <button
                        key={q}
                        onClick={() => handleQualityChange(q)}
                        className={`w-full text-right px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                          selectedQuality === q
                            ? 'bg-brand-primary text-white'
                            : 'text-slate-300 hover:bg-brand-card'
                        }`}
                      >
                        {q} {q === '1080p' ? 'FHD' : q === '720p' ? 'HD' : 'SD'}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <button
                onClick={toggleFullscreen}
                className="p-2 rounded-lg bg-white/10 hover:bg-white/20 transition"
                aria-label="ملء الشاشة"
              >
                <Maximize className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

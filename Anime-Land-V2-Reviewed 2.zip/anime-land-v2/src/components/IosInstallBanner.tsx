'use client';

import React, { useEffect, useState } from 'react';
import { Share, PlusSquare, X } from 'lucide-react';

export default function IosInstallBanner() {
  const [showBanner, setShowBanner] = useState(false);

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    }

    const isIos = /iphone|ipad|ipod/i.test(window.navigator.userAgent);
    const isStandalone =
      ('standalone' in window.navigator && (window.navigator as any).standalone) ||
      window.matchMedia('(display-mode: standalone)').matches;
    const dismissed = localStorage.getItem('animeland_ios_prompt_dismissed');

    if (isIos && !isStandalone && !dismissed) {
      setShowBanner(true);
    }
  }, []);

  if (!showBanner) return null;

  return (
    <div className="fixed bottom-20 inset-x-3 z-40 md:hidden rounded-2xl bg-brand-surface/95 backdrop-blur-xl border border-brand-primary/50 p-4 shadow-2xl text-white">
      <button
        onClick={() => {
          localStorage.setItem('animeland_ios_prompt_dismissed', '1');
          setShowBanner(false);
        }}
        aria-label="إغلاق"
        className="absolute top-3 left-3 text-slate-400 hover:text-white"
      >
        <X className="w-4 h-4" />
      </button>
      <div className="flex items-start gap-3">
        <img src="/icon.svg" alt="Anime Land" className="w-11 h-11 rounded-xl shrink-0" />
        <div className="space-y-1 text-xs">
          <p className="font-extrabold text-sm text-white">ثبّت تطبيق Anime Land على iPhone</p>
          <p className="text-slate-300 leading-relaxed flex flex-wrap items-center gap-1">
            اضغط على زر المشاركة <Share className="w-3.5 h-3.5 inline text-brand-primary" /> في أسفل Safari ثم اختر
            <span className="font-bold text-white inline-flex items-center gap-1">
              <PlusSquare className="w-3.5 h-3.5 text-brand-accent" /> إضافة إلى الشاشة الرئيسية
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}

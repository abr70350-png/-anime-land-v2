'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  Home,
  Compass,
  Heart,
  User,
  Bell,
  Search,
  ShieldCheck,
  Sun,
  Moon,
  Sparkles,
  LogIn,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';

export default function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const { user, notifications, theme, toggleTheme, markNotificationsRead } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [showNotifs, setShowNotifs] = useState(false);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    router.push(`/library?q=${encodeURIComponent(searchQuery)}`);
  };

  const navLinks = [
    { href: '/', label: 'الرئيسية', icon: Home },
    { href: '/library', label: 'المكتبة', icon: Compass },
    { href: '/profile?tab=favorites', label: 'المفضلة', icon: Heart },
  ];

  if (user?.role === 'ADMIN') {
    navLinks.push({ href: '/admin', label: 'لوحة المشرف', icon: ShieldCheck });
  }

  return (
    <>
      <header className="sticky top-0 z-50 border-b border-slate-200/80 dark:border-brand-border/80 bg-white/90 dark:bg-brand-bg/90 backdrop-blur-xl pt-[env(safe-area-inset-top)]">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <Link href="/" className="flex items-center gap-2.5 shrink-0 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-brand-primary to-brand-accent flex items-center justify-center text-white shadow-lg shadow-brand-primary/30 group-hover:scale-105 transition">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold text-lg tracking-tight bg-gradient-to-l from-brand-primary to-brand-accent bg-clip-text text-transparent">
                Anime Land
              </span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400 -mt-1">
                أنمي لاند المرخص
              </span>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((item) => {
              const Icon = item.icon;
              const active = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition ${
                    active
                      ? 'bg-brand-primary text-white shadow-md shadow-brand-primary/25'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-brand-surface'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>

          <form onSubmit={handleSearchSubmit} className="flex-1 max-w-md hidden sm:flex relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث بالعربية، الإنجليزية، أو اليابانية..."
              className="w-full bg-slate-100 dark:bg-brand-surface border border-slate-200 dark:border-brand-border rounded-xl py-2 pr-10 pl-4 text-sm focus:outline-none focus:border-brand-primary transition"
            />
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
          </form>

          <div className="flex items-center gap-2">
            <button
              onClick={toggleTheme}
              aria-label="تبديل المظهر"
              className="p-2.5 rounded-xl bg-slate-100 dark:bg-brand-surface border border-slate-200 dark:border-brand-border text-slate-700 dark:text-slate-200 hover:border-brand-primary transition"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            {user && (
              <div className="relative">
                <button
                  onClick={() => {
                    setShowNotifs(!showNotifs);
                    if (!showNotifs && unreadCount > 0) markNotificationsRead();
                  }}
                  className="p-2.5 rounded-xl bg-slate-100 dark:bg-brand-surface border border-slate-200 dark:border-brand-border relative hover:border-brand-primary transition"
                >
                  <Bell className="w-4 h-4" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -left-1 w-4 h-4 rounded-full bg-brand-accent text-white text-[10px] font-bold flex items-center justify-center">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {showNotifs && (
                  <div className="absolute left-0 mt-2 w-80 rounded-2xl bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border shadow-2xl p-3 z-50">
                    <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-200 dark:border-brand-border">
                      <span className="font-bold text-sm">الإشعارات</span>
                      <span className="text-xs text-slate-400">{notifications.length} تنبيه</span>
                    </div>
                    {notifications.length === 0 ? (
                      <p className="text-xs text-slate-400 py-6 text-center">لا توجد إشعارات جديدة حالياً</p>
                    ) : (
                      <div className="max-h-72 overflow-y-auto space-y-2">
                        {notifications.map((n) => (
                          <Link
                            key={n.id}
                            href={n.link}
                            onClick={() => setShowNotifs(false)}
                            className="block p-2.5 rounded-xl bg-slate-50 dark:bg-brand-card hover:border-brand-primary border border-transparent transition"
                          >
                            <p className="text-xs font-bold text-brand-primary">{n.title}</p>
                            <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">{n.message}</p>
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {user ? (
              <Link
                href="/profile"
                className="flex items-center gap-2 pl-3 pr-1.5 py-1 rounded-xl bg-slate-100 dark:bg-brand-surface border border-slate-200 dark:border-brand-border hover:border-brand-primary transition"
              >
                <img
                  src={user.avatarUrl}
                  alt={user.username}
                  className="w-7 h-7 rounded-lg object-cover"
                />
                <span className="text-xs font-bold hidden sm:inline">{user.username}</span>
              </Link>
            ) : (
              <Link
                href="/auth"
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-brand-primary hover:bg-brand-primaryHover text-white text-xs font-bold shadow-md shadow-brand-primary/25 transition"
              >
                <LogIn className="w-4 h-4" />
                <span>دخول</span>
              </Link>
            )}
          </div>
        </div>
      </header>

      <nav className="md:hidden fixed bottom-0 inset-x-0 z-50 bg-white/95 dark:bg-brand-surface/95 backdrop-blur-xl border-t border-slate-200 dark:border-brand-border px-2 pt-1.5 pb-[calc(0.4rem+env(safe-area-inset-bottom))] flex items-center justify-around">
        <Link
          href="/"
          className={`flex flex-col items-center gap-1 p-1.5 rounded-xl text-[11px] font-semibold ${
            pathname === '/' ? 'text-brand-primary' : 'text-slate-400'
          }`}
        >
          <Home className="w-5 h-5" />
          <span>الرئيسية</span>
        </Link>
        <Link
          href="/library"
          className={`flex flex-col items-center gap-1 p-1.5 rounded-xl text-[11px] font-semibold ${
            pathname === '/library' ? 'text-brand-primary' : 'text-slate-400'
          }`}
        >
          <Compass className="w-5 h-5" />
          <span>المكتبة</span>
        </Link>
        <Link
          href="/profile?tab=favorites"
          className={`flex flex-col items-center gap-1 p-1.5 rounded-xl text-[11px] font-semibold ${
            pathname === '/profile' ? 'text-brand-primary' : 'text-slate-400'
          }`}
        >
          <Heart className="w-5 h-5" />
          <span>المفضلة</span>
        </Link>
        {user?.role === 'ADMIN' ? (
          <Link
            href="/admin"
            className={`flex flex-col items-center gap-1 p-1.5 rounded-xl text-[11px] font-semibold ${
              pathname === '/admin' ? 'text-brand-primary' : 'text-slate-400'
            }`}
          >
            <ShieldCheck className="w-5 h-5" />
            <span>المشرف</span>
          </Link>
        ) : (
          <Link
            href={user ? '/profile' : '/auth'}
            className={`flex flex-col items-center gap-1 p-1.5 rounded-xl text-[11px] font-semibold ${
              pathname === '/auth' ? 'text-brand-primary' : 'text-slate-400'
            }`}
          >
            <User className="w-5 h-5" />
            <span>{user ? 'حسابي' : 'الدخول'}</span>
          </Link>
        )}
      </nav>
    </>
  );
}

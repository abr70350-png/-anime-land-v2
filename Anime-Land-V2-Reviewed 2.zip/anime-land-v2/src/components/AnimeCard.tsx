import React from 'react';
import Link from 'next/link';
import { Star, Play, Tv } from 'lucide-react';

export interface AnimeCardData {
  id: string;
  slug: string;
  titleAr: string;
  titleEn: string;
  coverImage: string;
  releaseYear: number;
  status: string;
  ageRating: string;
  avgRating: number;
  episodesCount: number;
  genres: string;
}

export default function AnimeCard({ anime }: { anime: AnimeCardData }) {
  const firstGenre = anime.genres.split(',')[0] || 'أنمي';

  return (
    <Link
      href={`/anime/${anime.slug}`}
      className="group relative flex flex-col rounded-2xl overflow-hidden bg-white dark:bg-brand-card border border-slate-200 dark:border-brand-border hover:border-brand-primary/80 transition-all duration-300 hover:-translate-y-1 shadow-sm hover:shadow-xl hover:shadow-brand-primary/10"
    >
      <div className="relative aspect-[2/3] w-full overflow-hidden bg-slate-900">
        <img
          src={anime.coverImage}
          alt={anime.titleAr}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-80 group-hover:opacity-95 transition" />

        <div className="absolute top-2.5 right-2.5 flex items-center gap-1 px-2 py-1 rounded-lg bg-black/75 backdrop-blur-md text-amber-400 text-xs font-bold">
          <Star className="w-3.5 h-3.5 fill-amber-400" />
          <span>{anime.avgRating.toFixed(1)}</span>
        </div>

        <div
          className={`absolute top-2.5 left-2.5 px-2 py-0.5 rounded-lg text-[11px] font-bold backdrop-blur-md ${
            anime.status === 'مستمر'
              ? 'bg-emerald-500/90 text-white'
              : 'bg-brand-primary/90 text-white'
          }`}
        >
          {anime.status}
        </div>

        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="w-12 h-12 rounded-full bg-brand-primary text-white flex items-center justify-center shadow-lg shadow-brand-primary/50">
            <Play className="w-5 h-5 fill-white mr-0.5" />
          </div>
        </div>

        <div className="absolute bottom-2.5 inset-x-2.5 flex items-center justify-between text-[11px] text-slate-200">
          <span className="px-2 py-0.5 rounded bg-white/15 backdrop-blur-sm">{firstGenre}</span>
          <span className="flex items-center gap-1">
            <Tv className="w-3 h-3" />
            {anime.episodesCount} حلقة
          </span>
        </div>
      </div>

      <div className="p-3 flex flex-col gap-0.5">
        <h3 className="font-bold text-sm line-clamp-1 group-hover:text-brand-primary transition">
          {anime.titleAr}
        </h3>
        <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <span className="line-clamp-1">{anime.titleEn}</span>
          <span className="shrink-0">{anime.releaseYear}</span>
        </div>
      </div>
    </Link>
  );
}

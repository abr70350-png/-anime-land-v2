'use client';

import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import { ShieldCheck, PlusCircle, Trash2, Flag, Tv, CheckCircle } from 'lucide-react';

export default function AdminDashboardPage() {
  const { user, loadingAuth } = useApp();
  const [animes, setAnimes] = useState<any[]>([]);
  const [reports, setReports] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'anime' | 'episode' | 'reports'>('anime');

  const [animeForm, setAnimeForm] = useState({
    titleAr: '',
    titleEn: '',
    titleJp: '',
    synopsisAr: '',
    coverImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx114124-614231072.jpg',
    bannerImage: 'https://s4.anilist.co/file/anilistcdn/media/anime/banner/114124-794769260.jpg',
    releaseYear: 2026,
    season: 'خريف',
    status: 'مستمر',
    ageRating: '+13',
    seasonsCount: 1,
    episodesCount: 12,
    genres: 'أكشن,مغامرات',
    isTrending: true,
  });

  const [epForm, setEpForm] = useState({
    animeId: '',
    seasonNumber: 1,
    episodeNumber: 1,
    titleAr: '',
    videoUrl1080: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    videoUrl720: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
  });

  const loadData = async () => {
    const [aRes, rRes] = await Promise.all([fetch('/api/anime'), fetch('/api/reports')]);
    const aData = await aRes.json();
    const rData = await rRes.json();
    setAnimes(aData.animes || []);
    setReports(rData.reports || []);
    if (aData.animes?.[0] && !epForm.animeId) {
      setEpForm((prev) => ({ ...prev, animeId: aData.animes[0].id }));
    }
  };

  useEffect(() => {
    if (user?.role === 'ADMIN') loadData();
  }, [user]);

  if (loadingAuth) return <div className="p-12 text-center">جاري التحقق من الصلاحيات...</div>;
  if (!user || user.role !== 'ADMIN') {
    return (
      <div className="max-w-md mx-auto p-12 text-center font-bold text-rose-500">
        عذراً، هذه الصفحة مخصصة للمشرفين فقط.
      </div>
    );
  }

  const handleCreateAnime = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/anime', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(animeForm),
    });
    if (res.ok) {
      alert('تمت إضافة الأنمي بنجاح!');
      setAnimeForm({ ...animeForm, titleAr: '', titleEn: '', titleJp: '', synopsisAr: '' });
      loadData();
    }
  };

  const handleDeleteAnime = async (slug: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الأنمي وجميع حلقاته؟')) return;
    await fetch(`/api/anime/${slug}`, { method: 'DELETE' });
    loadData();
  };

  const handleCreateEpisode = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/episodes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(epForm),
    });
    if (res.ok) {
      alert('تم نشر الحلقة المرخصة وإرسال إشعارات تلقائية لجميع المتابعين!');
      setEpForm({ ...epForm, episodeNumber: epForm.episodeNumber + 1, titleAr: '' });
      loadData();
    } else {
      const err = await res.json();
      alert(err.error || 'حدث خطأ');
    }
  };

  const handleResolveReport = async (reportId: string) => {
    await fetch('/api/reports', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reportId, status: 'RESOLVED' }),
    });
    loadData();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-brand-primary/20 text-brand-primary flex items-center justify-center">
          <ShieldCheck className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-2xl font-extrabold">لوحة تحكم المشرف</h1>
          <p className="text-xs text-slate-400">إدارة الأنميات، نشر الحلقات المرخصة، ومعالجة بلاغات المستخدمين</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setActiveTab('anime')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 ${
            activeTab === 'anime' ? 'bg-brand-primary text-white' : 'bg-white dark:bg-brand-surface'
          }`}
        >
          <PlusCircle className="w-4 h-4" />
          <span>إدارة الأنميات ({animes.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('episode')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 ${
            activeTab === 'episode' ? 'bg-brand-primary text-white' : 'bg-white dark:bg-brand-surface'
          }`}
        >
          <Tv className="w-4 h-4" />
          <span>إضافة حلقة مرخصة</span>
        </button>
        <button
          onClick={() => setActiveTab('reports')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 ${
            activeTab === 'reports' ? 'bg-brand-primary text-white' : 'bg-white dark:bg-brand-surface'
          }`}
        >
          <Flag className="w-4 h-4" />
          <span>البلاغات ({reports.filter((r) => r.status === 'OPEN').length} مفتوح)</span>
        </button>
      </div>

      {activeTab === 'anime' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <form
            onSubmit={handleCreateAnime}
            className="bg-white dark:bg-brand-surface p-6 rounded-2xl border border-slate-200 dark:border-brand-border space-y-4"
          >
            <h2 className="font-extrabold text-lg">إضافة أنمي جديد</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                required
                placeholder="الاسم بالعربية"
                value={animeForm.titleAr}
                onChange={(e) => setAnimeForm({ ...animeForm, titleAr: e.target.value })}
                className="bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-xs"
              />
              <input
                required
                placeholder="الاسم بالإنجليزية"
                value={animeForm.titleEn}
                onChange={(e) => setAnimeForm({ ...animeForm, titleEn: e.target.value })}
                className="bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-xs"
              />
              <input
                placeholder="الاسم باليابانية"
                value={animeForm.titleJp}
                onChange={(e) => setAnimeForm({ ...animeForm, titleJp: e.target.value })}
                className="bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-xs"
              />
              <input
                placeholder="التصنيفات (أكشن,غموض)"
                value={animeForm.genres}
                onChange={(e) => setAnimeForm({ ...animeForm, genres: e.target.value })}
                className="bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-xs"
              />
              <input
                required
                placeholder="رابط صورة الغلاف"
                value={animeForm.coverImage}
                onChange={(e) => setAnimeForm({ ...animeForm, coverImage: e.target.value })}
                className="bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-xs"
              />
              <select
                value={animeForm.ageRating}
                onChange={(e) => setAnimeForm({ ...animeForm, ageRating: e.target.value })}
                className="bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-xs"
              >
                <option value="عائلي">عائلي</option>
                <option value="+13">+13</option>
                <option value="+16">+16</option>
                <option value="+17">+17</option>
              </select>
            </div>
            <textarea
              required
              rows={3}
              placeholder="القصة الكاملة للأنمي..."
              value={animeForm.synopsisAr}
              onChange={(e) => setAnimeForm({ ...animeForm, synopsisAr: e.target.value })}
              className="w-full bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-xs"
            />
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-brand-primary text-white text-xs font-bold"
            >
              حفظ ونشر الأنمي
            </button>
          </form>

          <div className="space-y-3">
            <h2 className="font-extrabold text-lg">الأنميات المنشورة</h2>
            {animes.map((a) => (
              <div
                key={a.id}
                className="flex items-center justify-between p-3 rounded-2xl bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border"
              >
                <div className="flex items-center gap-3">
                  <img src={a.coverImage} alt={a.titleAr} className="w-12 h-16 rounded-lg object-cover" />
                  <div>
                    <h3 className="font-bold text-sm">{a.titleAr}</h3>
                    <p className="text-xs text-slate-400">
                      {a.titleEn} • {a._count?.episodes || 0} حلقات منشورة
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => handleDeleteAnime(a.slug)}
                  className="p-2 rounded-xl bg-rose-500/15 text-rose-500 hover:bg-rose-500 hover:text-white transition"
                  title="حذف الأنمي"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'episode' && (
        <form
          onSubmit={handleCreateEpisode}
          className="max-w-xl bg-white dark:bg-brand-surface p-6 rounded-2xl border border-slate-200 dark:border-brand-border space-y-4"
        >
          <h2 className="font-extrabold text-lg">رفع حلقة مرخصة جديدة</h2>
          <p className="text-xs text-slate-400">
            عند نشر الحلقة، سيصل إشعار فوري لجميع المستخدمين المتابعين لهذا الأنمي.
          </p>

          <div className="space-y-1">
            <label className="text-xs font-bold">اختر الأنمي</label>
            <select
              value={epForm.animeId}
              onChange={(e) => setEpForm({ ...epForm, animeId: e.target.value })}
              className="w-full bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-xs"
            >
              {animes.map((a) => (
                <option key={a.id} value={a.id}>{a.titleAr}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold">رقم الموسم</label>
              <input
                type="number"
                min={1}
                value={epForm.seasonNumber}
                onChange={(e) => setEpForm({ ...epForm, seasonNumber: Number(e.target.value) })}
                className="w-full bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-xs"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold">رقم الحلقة</label>
              <input
                type="number"
                min={1}
                value={epForm.episodeNumber}
                onChange={(e) => setEpForm({ ...epForm, episodeNumber: Number(e.target.value) })}
                className="w-full bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-xs"
              />
            </div>
          </div>

          <input
            required
            placeholder="عنوان الحلقة بالعربية"
            value={epForm.titleAr}
            onChange={(e) => setEpForm({ ...epForm, titleAr: e.target.value })}
            className="w-full bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-xs"
          />

          <input
            required
            placeholder="رابط البث المرخص 1080p (MP4 / HLS)"
            value={epForm.videoUrl1080}
            onChange={(e) => setEpForm({ ...epForm, videoUrl1080: e.target.value })}
            className="w-full bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-xs"
          />

          <button type="submit" className="w-full py-3 rounded-xl bg-brand-primary text-white text-xs font-bold">
            نشر الحلقة وإرسال الإشعارات
          </button>
        </form>
      )}

      {activeTab === 'reports' && (
        <div className="space-y-3">
          {reports.length === 0 ? (
            <p className="text-sm text-slate-400">لا توجد بلاغات مسجلة حالياً.</p>
          ) : (
            reports.map((rep) => (
              <div
                key={rep.id}
                className="p-4 rounded-2xl bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border flex items-center justify-between"
              >
                <div>
                  <span className="px-2 py-0.5 rounded bg-rose-500/15 text-rose-500 text-[11px] font-bold">
                    {rep.targetType}
                  </span>
                  <h3 className="font-bold text-sm mt-1">{rep.reason}</h3>
                  <p className="text-xs text-slate-400">بواسطة: {rep.user?.username}</p>
                </div>

                {rep.status === 'OPEN' ? (
                  <button
                    onClick={() => handleResolveReport(rep.id)}
                    className="px-3.5 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold flex items-center gap-1"
                  >
                    <CheckCircle className="w-4 h-4" />
                    <span>تمت المعالجة</span>
                  </button>
                ) : (
                  <span className="text-xs font-bold text-emerald-500">مغلق ✓</span>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

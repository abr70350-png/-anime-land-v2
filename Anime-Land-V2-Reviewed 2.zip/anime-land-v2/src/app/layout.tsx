import type { Metadata, Viewport } from 'next';
import { Cairo } from 'next/font/google';
import './globals.css';
import { AppProvider } from '@/context/AppContext';
import Navbar from '@/components/Navbar';
import IosInstallBanner from '@/components/IosInstallBanner';

const cairo = Cairo({
  subsets: ['arabic', 'latin'],
  weight: ['400', '600', '700', '800'],
  variable: '--font-cairo',
});

export const metadata: Metadata = {
  title: 'Anime Land | أنمي لاند - منصة الأنمي المرخصة',
  description: 'شاهد وتابع أحدث الأنميات المرخصة بجودة عالية مع واجهة عربية متكاملة قابلة للتثبيت على iPhone.',
  manifest: '/manifest.json',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'Anime Land',
  },
  icons: {
    icon: '/icon.svg',
    apple: '/apple-touch-icon.png',
  },
};

export const viewport: Viewport = {
  themeColor: '#090B10',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  viewportFit: 'cover',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className="dark">
      <body className={`${cairo.variable} font-arabic min-h-screen flex flex-col pb-24 md:pb-0`}>
        <AppProvider>
          <Navbar />
          <main className="flex-1">{children}</main>
          <IosInstallBanner />
          <footer className="border-t border-slate-200 dark:border-brand-border py-8 px-4 mt-16 bg-white dark:bg-brand-surface/50">
            <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
              <p>© 2026 Anime Land (أنمي لاند). جميع الحقوق محفوظة.</p>
              <p>يعتمد التطبيق على مصادر بيانات وصفية عامة وبث مرخص وقانوني 100%.</p>
            </div>
          </footer>
        </AppProvider>
      </body>
    </html>
  );
}

'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import {
  Heart,
  Bell,
  BellRing,
  Star,
  Play,
  Users,
  Layers,
  Tv,
  MessageSquare,
  ThumbsUp,
  Flag,
  Send,
  ShieldCheck,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';

export default function AnimeDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const slug = params.slug as string;
  const { user, refreshUserData } = useApp();

  const [anime, setAnime] = useState<any>(null);
  const [userState, setUserState] = useState<any>({
    isFavorite: false,
    isSubscribed: false,
    userRating: null,
    watchProgress: {},
  });
  const [loading, setLoading] = useState(true);
  const [commentText, setCommentText] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);
  const [reportModal, setReportModal] = useState<{ type: string; id: string } | null>(null);
  const [reportReason, setReportReason] = useState('مشكلة في الترجمة أو الجودة');
  const [toast, setToast] = useState('');

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 3000);
  };

  useEffect(() => {
    fetch(`/api/anime/${slug}`)
      .then((res) => res.json())
      .then((data) => {
        setAnime(data.anime || null);
        if (data.userState) setUserState(data.userState);
      })
      .finally(() => setLoading(false));
  }, [slug]);

  const handleToggleFavorite = async () => {
    if (!user) return router.push('/auth');
    const res = await fetch('/api/favorites', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ animeId: anime.id }),
    });
    const data = await res.json();
    setUserState((prev: any) => ({ ...prev, isFavorite: data.isFavorite }));
    refreshUserData();
    showToast(data.isFavorite ? 'تمت الإضافة إلى قائمة المفضلة' : 'تمت الإزالة من المفضلة');
  };

  const handleToggleSubscribe = async () => {
    if (!user) return router.push('/auth');
    const res = await fetch('/api/subscriptions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ animeId: anime.id }),
    });
    const data = await res.json();
    setUserState((prev: any) => ({ ...prev, isSubscribed: data.isSubscribed }));
    refreshUserData();
    showToast(data.isSubscribed ? 'تم تفعيل إشعارات الحلقات الجديدة' : 'تم إيقاف الإشعارات لهذا الأنمي');
  };

  const handleRate = async (score: number) => {
    if (!user) return router.push('/auth');
    const res = await fetch('/api/ratings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ animeId: anime.id, score }),
    });
    const data = await res.json();
    if (data.userRating) {
      setUserState((prev: any) => ({ ...prev, userRating: data.userRating }));
      setAnime((prev: any) => ({ ...prev, avgRating: data.avgRating }));
      showToast(`تم تسجيل تقييمك (${score}/10)`);
    }
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return router.push('/auth');
    if (!commentText.trim()) return;
    setSubmittingComment(true);
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ animeId: anime.id, content: commentText }),
      });
      const data = await res.json();
      if (data.comment) {
        setAnime((prev: any) => ({ ...prev, comments: [data.comment, ...prev.comments] }));
        setCommentText('');
        showToast('تم نشر تعليقك');
      }
    } finally {
      setSubmittingComment(false);
    }
  };

  const handleLikeComment = async (commentId: string) => {
    const res = await fetch('/api/comments', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ commentId }),
    });
    const data = await res.json();
    setAnime((prev: any) => ({
      ...prev,
      comments: prev.comments.map((c: any) => (c.id === commentId ? { ...c, likes: data.likes } : c)),
    }));
  };

  const handleSendReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return router.push('/auth');
    if (!reportModal) return;
    await fetch('/api/reports', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        targetType: reportModal.type,
        targetId: reportModal.id,
        reason: reportReason,
      }),
    });
    setReportModal(null);
    showToast('تم إرسال البلاغ للمشرفين بنجاح');
  };

  if (loading) return <div className="max-w-7xl mx-auto p-10 text-center">جاري تحميل تفاصيل الأنمي...</div>;
  if (!anime) return <div className="max-w-7xl mx-auto p-10 text-center font-bold">الأنمي غير موجود</div>;

  const genresList = anime.genres.split(',');
  const firstEpisode = anime.episodes[0];

  return (
    <div className="pb-12">
      {toast && (
        <div className="fixed bottom-24 md:bottom-6 left-6 z-50 bg-brand-primary text-white px-4 py-2.5 rounded-xl shadow-xl text-xs font-bold">
          {toast}
        </div>
      )}

      <div className="relative h-64 md:h-80 w-full overflow-hidden">
        <img
          src={anime.bannerImage || anime.coverImage}
          alt={anime.titleAr}
          className="w-full h-full object-cover blur-[2px] scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-50 via-slate-900/75 to-black/50 dark:from-brand-bg dark:via-brand-bg/80 dark:to-black/40" />
      </div>

      <div className="max-w-7xl mx-auto px-4 -mt-36 relative z-10 space-y-10">
        <div className="flex flex-col md:flex-row gap-6 md:gap-8">
          <div className="w-48 md:w-64 shrink-0 mx-auto md:mx-0">
            <img
              src={anime.coverImage}
              alt={anime.titleAr}
              className="w-full aspect-[2/3] object-cover rounded-2xl shadow-2xl border-2 border-white/10"
            />
          </div>

          <div className="flex-1 space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-lg bg-brand-primary text-white text-xs font-bold">
                {anime.status}
              </span>
              <span className="px-3 py-1 rounded-lg bg-amber-500/20 text-amber-400 text-xs font-bold flex items-center gap-1">
                <Star className="w-3.5 h-3.5 fill-amber-400" />
                {anime.avgRating} / 10
              </span>
              <span className="px-3 py-1 rounded-lg bg-rose-500/20 text-rose-400 text-xs font-bold">
                التصنيف العمري: {anime.ageRating}
              </span>
              <span className="px-3 py-1 rounded-lg bg-emerald-500/15 text-emerald-400 text-xs font-bold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                {anime.studio}
              </span>
            </div>

            <div>
              <h1 className="text-2xl md:text-4xl font-extrabold">{anime.titleAr}</h1>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                {anime.titleEn} • <span>{anime.titleJp}</span>
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              {genresList.map((g: string) => (
                <Link
                  key={g}
                  href={`/library?genre=${encodeURIComponent(g)}`}
                  className="px-3 py-1 rounded-xl bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border text-xs font-semibold hover:border-brand-primary transition"
                >
                  {g}
                </Link>
              ))}
            </div>

            <div className="bg-white dark:bg-brand-surface p-4 rounded-2xl border border-slate-200 dark:border-brand-border">
              <h2 className="text-sm font-bold text-brand-primary mb-1.5">القصة الكاملة</h2>
              <p className="text-sm leading-relaxed text-slate-700 dark:text-slate-200">
                {anime.synopsisAr}
              </p>
            </div>

            <div className="grid grid-cols-3 gap-3 max-w-md">
              <div className="p-3 rounded-xl bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border text-center">
                <Layers className="w-4 h-4 mx-auto text-brand-primary mb-1" />
                <p className="text-xs text-slate-400">المواسم</p>
                <p className="font-extrabold text-base">{anime.seasonsCount}</p>
              </div>
              <div className="p-3 rounded-xl bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border text-center">
                <Tv className="w-4 h-4 mx-auto text-brand-accent mb-1" />
                <p className="text-xs text-slate-400">الحلقات</p>
                <p className="font-extrabold text-base">{anime.episodesCount}</p>
              </div>
              <div className="p-3 rounded-xl bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border text-center">
                <Star className="w-4 h-4 mx-auto text-amber-400 mb-1" />
                <p className="text-xs text-slate-400">سنة الإصدار</p>
                <p className="font-extrabold text-base">{anime.releaseYear}</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              {firstEpisode && (
                <Link
                  href={`/watch/${anime.slug}/${firstEpisode.id}`}
                  className="px-6 py-3 rounded-xl bg-brand-primary hover:bg-brand-primaryHover text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-brand-primary/30 transition"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>ابدأ المشاهدة</span>
                </Link>
              )}

              <button
                onClick={handleToggleFavorite}
                className={`px-4 py-3 rounded-xl font-bold text-sm flex items-center gap-2 border transition ${
                  userState.isFavorite
                    ? 'bg-rose-500/15 border-rose-500 text-rose-500'
                    : 'bg-white dark:bg-brand-surface border-slate-200 dark:border-brand-border hover:border-brand-primary'
                }`}
              >
                <Heart className={`w-4 h-4 ${userState.isFavorite ? 'fill-rose-500' : ''}`} />
                <span>{userState.isFavorite ? 'في المفضلة' : 'إضافة للمفضلة'}</span>
              </button>

              <button
                onClick={handleToggleSubscribe}
                className={`px-4 py-3 rounded-xl font-bold text-sm flex items-center gap-2 border transition ${
                  userState.isSubscribed
                    ? 'bg-emerald-500/15 border-emerald-500 text-emerald-500'
                    : 'bg-white dark:bg-brand-surface border-slate-200 dark:border-brand-border hover:border-brand-primary'
                }`}
              >
                {userState.isSubscribed ? <BellRing className="w-4 h-4" /> : <Bell className="w-4 h-4" />}
                <span>{userState.isSubscribed ? 'مُتابَع (الإشعارات مفعلة)' : 'متابعة الحلقات'}</span>
              </button>

              <button
                onClick={() => setReportModal({ type: 'ANIME', id: anime.id })}
                className="p-3 rounded-xl bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border text-slate-400 hover:text-rose-500 transition"
                title="إبلاغ عن مشكلة"
              >
                <Flag className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-2">
              <span className="text-xs font-bold text-slate-400">قيّم هذا الأنمي:</span>
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                <button
                  key={num}
                  onClick={() => handleRate(num)}
                  className={`w-7 h-7 rounded-lg text-xs font-bold transition ${
                    userState.userRating === num
                      ? 'bg-amber-500 text-black'
                      : 'bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border hover:border-amber-400'
                  }`}
                >
                  {num}
                </button>
              ))}
            </div>
          </div>
        </div>

        {anime.characters?.length > 0 && (
          <section className="space-y-4">
            <h2 className="text-xl font-extrabold flex items-center gap-2">
              <Users className="w-5 h-5 text-brand-primary" />
              <span>الشخصيات الرئيسية</span>
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {anime.characters.map((char: any) => (
                <div
                  key={char.id}
                  className="flex items-center gap-3.5 p-3 rounded-2xl bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border"
                >
                  <img
                    src={char.imageUrl}
                    alt={char.nameAr}
                    className="w-16 h-16 rounded-xl object-cover bg-slate-800"
                  />
                  <div>
                    <h3 className="font-bold text-sm">{char.nameAr}</h3>
                    <p className="text-xs text-slate-400">{char.nameJp}</p>
                    <span className="inline-block mt-1 px-2 py-0.5 rounded bg-brand-primary/15 text-brand-primary text-[11px] font-semibold">
                      {char.role} {char.voiceActor ? `• ${char.voiceActor}` : ''}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        <section className="space-y-4">
          <h2 className="text-xl font-extrabold flex items-center gap-2">
            <Tv className="w-5 h-5 text-brand-accent" />
            <span>قائمة الحلقات المتوفرة ({anime.episodes.length})</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {anime.episodes.map((ep: any) => {
              const prog = userState.watchProgress?.[ep.id];
              const pct = prog ? Math.min(100, Math.round((prog.progressSeconds / prog.durationSeconds) * 100)) : 0;

              return (
                <Link
                  key={ep.id}
                  href={`/watch/${anime.slug}/${ep.id}`}
                  className="group rounded-2xl overflow-hidden bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border hover:border-brand-primary transition"
                >
                  <div className="relative aspect-video bg-slate-900">
                    <img
                      src={ep.thumbnailUrl}
                      alt={ep.titleAr}
                      className="w-full h-full object-cover group-hover:scale-105 transition"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      <div className="w-11 h-11 rounded-full bg-brand-primary text-white flex items-center justify-center shadow-lg">
                        <Play className="w-5 h-5 fill-white mr-0.5" />
                      </div>
                    </div>
                    <span className="absolute top-2.5 right-2.5 px-2.5 py-1 rounded-lg bg-black/80 text-white text-xs font-bold">
                      الموسم {ep.seasonNumber} • الحلقة {ep.episodeNumber}
                    </span>
                    {pct > 0 && (
                      <div className="absolute bottom-0 inset-x-0 h-1.5 bg-white/20">
                        <div className="h-full bg-brand-primary" style={{ width: `${pct}%` }} />
                      </div>
                    )}
                  </div>
                  <div className="p-3.5 flex items-center justify-between">
                    <h3 className="font-bold text-sm group-hover:text-brand-primary transition">
                      {ep.titleAr}
                    </h3>
                    {pct > 0 && (
                      <span className="text-[11px] font-bold text-brand-primary">
                        {prog.completed ? 'مكتملة' : `${pct}%`}
                      </span>
                    )}
                  </div>
                </Link>
              );
            })}
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-extrabold flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-brand-primary" />
            <span>آراء وتعليقات المتابعين ({anime.comments.length})</span>
          </h2>

          <form onSubmit={handleAddComment} className="flex gap-3">
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder={user ? 'اكتب انطباعك حول الأنمي...' : 'سجّل الدخول للمشاركة في النقاش'}
              className="flex-1 bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-brand-primary"
            />
            <button
              type="submit"
              disabled={submittingComment}
              className="px-5 py-3 rounded-xl bg-brand-primary hover:bg-brand-primaryHover text-white font-bold text-sm flex items-center gap-2 transition"
            >
              <Send className="w-4 h-4" />
              <span>نشر</span>
            </button>
          </form>

          <div className="space-y-3">
            {anime.comments.map((c: any) => (
              <div
                key={c.id}
                className="p-4 rounded-2xl bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border flex items-start justify-between gap-4"
              >
                <div className="flex items-start gap-3">
                  <img
                    src={c.user.avatarUrl}
                    alt={c.user.username}
                    className="w-10 h-10 rounded-xl object-cover"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm">{c.user.username}</span>
                      {c.user.role === 'ADMIN' && (
                        <span className="px-2 py-0.5 rounded bg-brand-primary/20 text-brand-primary text-[10px] font-bold">
                          مشرف
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-slate-700 dark:text-slate-200 mt-1">{c.content}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleLikeComment(c.id)}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-brand-card text-xs font-bold hover:text-brand-primary transition"
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                    <span>{c.likes}</span>
                  </button>
                  <button
                    onClick={() => setReportModal({ type: 'COMMENT', id: c.id })}
                    className="p-1.5 text-slate-400 hover:text-rose-500"
                    title="إبلاغ عن تعليق"
                  >
                    <Flag className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {reportModal && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <form
            onSubmit={handleSendReport}
            className="w-full max-w-md bg-white dark:bg-brand-surface border border-brand-border rounded-2xl p-6 space-y-4"
          >
            <h3 className="text-lg font-extrabold">إرسال بلاغ للإدارة</h3>
            <select
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
              className="w-full bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-3 text-sm"
            >
              <option>مشكلة في الترجمة أو الجودة</option>
              <option>رابط الفيديو لا يعمل</option>
              <option>تعليق مخالف لقواعد المجتمع</option>
              <option>تصنيف عمري غير دقيق</option>
            </select>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setReportModal(null)}
                className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-brand-card text-xs font-bold"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold"
              >
                إرسال البلاغ
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

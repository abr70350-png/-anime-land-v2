import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET() {
  const user = await getCurrentUser();
  if (!user || user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'صلاحيات المشرف مطلوبة' }, { status: 403 });
  }

  const reports = await prisma.report.findMany({
    orderBy: { createdAt: 'desc' },
    include: { user: { select: { username: true, email: true } } },
  });
  return NextResponse.json({ reports });
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'يرجى تسجيل الدخول لإرسال بلاغ' }, { status: 401 });

  const { targetType, targetId, reason, details } = await req.json();
  if (!targetType || !targetId || !reason) {
    return NextResponse.json({ error: 'بيانات البلاغ غير مكتملة' }, { status: 400 });
  }

  const report = await prisma.report.create({
    data: {
      userId: user.id,
      targetType,
      targetId,
      reason,
      details: details || '',
    },
  });

  return NextResponse.json({ report }, { status: 201 });
}

export async function PATCH(req: Request) {
  const user = await getCurrentUser();
  if (!user || user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
  }

  const { reportId, status } = await req.json();
  const report = await prisma.report.update({
    where: { id: reportId },
    data: { status },
  });
  return NextResponse.json({ report });
}

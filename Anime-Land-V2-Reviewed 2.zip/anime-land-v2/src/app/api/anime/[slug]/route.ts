import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET(
  _req: Request,
  { params }: { params: { slug: string } }
) {
  try {
    const anime = await prisma.anime.findUnique({
      where: { slug: params.slug },
      include: {
        characters: true,
        episodes: {
          orderBy: [{ seasonNumber: 'asc' }, { episodeNumber: 'asc' }],
        },
        comments: {
          include: {
            user: { select: { id: true, username: true, avatarUrl: true, role: true } },
            episode: { select: { episodeNumber: true, titleAr: true } },
          },
          orderBy: { createdAt: 'desc' },
          take: 50,
        },
      },
    });

    if (!anime) {
      return NextResponse.json({ error: 'الأنمي غير موجود' }, { status: 404 });
    }

    await prisma.anime.update({
      where: { id: anime.id },
      data: { viewsCount: { increment: 1 } },
    });

    const user = await getCurrentUser();
    const userState = {
      isFavorite: false,
      isSubscribed: false,
      userRating: null as number | null,
      watchProgress: {} as Record<string, { progressSeconds: number; durationSeconds: number; completed: boolean }>,
    };

    if (user) {
      const [fav, sub, rating, history] = await Promise.all([
        prisma.favorite.findUnique({ where: { userId_animeId: { userId: user.id, animeId: anime.id } } }),
        prisma.subscription.findUnique({ where: { userId_animeId: { userId: user.id, animeId: anime.id } } }),
        prisma.rating.findUnique({ where: { userId_animeId: { userId: user.id, animeId: anime.id } } }),
        prisma.watchHistory.findMany({
          where: { userId: user.id, episode: { animeId: anime.id } },
        }),
      ]);

      userState.isFavorite = Boolean(fav);
      userState.isSubscribed = Boolean(sub);
      userState.userRating = rating?.score ?? null;
      for (const h of history) {
        userState.watchProgress[h.episodeId] = {
          progressSeconds: h.progressSeconds,
          durationSeconds: h.durationSeconds,
          completed: h.completed,
        };
      }
    }

    return NextResponse.json({ anime, userState });
  } catch (error) {
    console.error('Anime detail error:', error);
    return NextResponse.json({ error: 'خطأ في جلب تفاصيل الأنمي' }, { status: 500 });
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: { slug: string } }
) {
  const user = await getCurrentUser();
  if (!user || user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
  }

  await prisma.anime.delete({ where: { slug: params.slug } });
  return NextResponse.json({ success: true });
}

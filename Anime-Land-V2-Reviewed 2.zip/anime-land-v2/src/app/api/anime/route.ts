import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get('q')?.trim() || '';
    const genre = searchParams.get('genre')?.trim() || '';
    const year = searchParams.get('year')?.trim() || '';
    const status = searchParams.get('status')?.trim() || '';
    const minRating = parseFloat(searchParams.get('minRating') || '0');
    const sort = searchParams.get('sort') || 'popular';

    const where: Record<string, unknown> = {};

    if (q) {
      where.OR = [
        { titleAr: { contains: q, mode: 'insensitive' } },
        { titleEn: { contains: q, mode: 'insensitive' } },
        { titleJp: { contains: q, mode: 'insensitive' } },
      ];
    }

    if (genre && genre !== 'الكل') {
      where.genres = { contains: genre };
    }

    if (year && year !== 'الكل') {
      where.releaseYear = parseInt(year, 10);
    }

    if (status && status !== 'الكل') {
      where.status = status;
    }

    if (!isNaN(minRating) && minRating > 0) {
      where.avgRating = { gte: minRating };
    }

    let orderBy: Record<string, string> = { viewsCount: 'desc' };
    if (sort === 'newest') orderBy = { releaseYear: 'desc' };
    if (sort === 'rating') orderBy = { avgRating: 'desc' };
    if (sort === 'recent') orderBy = { createdAt: 'desc' };

    const animes = await prisma.anime.findMany({
      where,
      orderBy,
      include: {
        _count: { select: { episodes: true, favorites: true } },
      },
    });

    return NextResponse.json({ animes });
  } catch (error) {
    console.error('Anime list error:', error);
    return NextResponse.json({ error: 'فشل جلب قائمة الأنمي' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user || user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'صلاحيات المشرف مطلوبة' }, { status: 403 });
  }

  try {
    const body = await req.json();
    const slug =
      body.slug ||
      body.titleEn
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '') +
        '-' +
        Date.now().toString().slice(-4);

    const anime = await prisma.anime.create({
      data: {
        slug,
        titleAr: body.titleAr,
        titleEn: body.titleEn,
        titleJp: body.titleJp || body.titleEn,
        synopsisAr: body.synopsisAr,
        coverImage: body.coverImage,
        bannerImage: body.bannerImage || body.coverImage,
        releaseYear: Number(body.releaseYear) || 2026,
        season: body.season || 'خريف',
        status: body.status || 'مستمر',
        ageRating: body.ageRating || '+13',
        seasonsCount: Number(body.seasonsCount) || 1,
        episodesCount: Number(body.episodesCount) || 12,
        studio: body.studio || 'استوديو مرخص',
        licenseSource: body.licenseSource || 'Licensed Official Stream',
        genres: body.genres || 'أكشن,مغامرات',
        isTrending: Boolean(body.isTrending),
        isFeatured: Boolean(body.isFeatured),
      },
    });

    return NextResponse.json({ anime }, { status: 201 });
  } catch (error) {
    console.error('Create anime error:', error);
    return NextResponse.json({ error: 'تعذر إضافة الأنمي' }, { status: 500 });
  }
}

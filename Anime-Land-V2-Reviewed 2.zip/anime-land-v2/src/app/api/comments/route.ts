import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'يرجى تسجيل الدخول للتعليق' }, { status: 401 });

  const { animeId, episodeId, content } = await req.json();
  if (!content || content.trim().length < 2) {
    return NextResponse.json({ error: 'التعليق قصير جداً' }, { status: 400 });
  }

  const comment = await prisma.comment.create({
    data: {
      userId: user.id,
      animeId,
      episodeId: episodeId || null,
      content: content.trim(),
    },
    include: {
      user: { select: { id: true, username: true, avatarUrl: true, role: true } },
      episode: { select: { episodeNumber: true, titleAr: true } },
    },
  });

  return NextResponse.json({ comment }, { status: 201 });
}

export async function PATCH(req: Request) {
  const { commentId } = await req.json();
  const updated = await prisma.comment.update({
    where: { id: commentId },
    data: { likes: { increment: 1 } },
  });
  return NextResponse.json({ likes: updated.likes });
}

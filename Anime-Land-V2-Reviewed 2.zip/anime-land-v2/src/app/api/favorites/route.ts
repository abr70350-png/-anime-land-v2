import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'يرجى تسجيل الدخول أولاً' }, { status: 401 });

  const { animeId } = await req.json();
  const existing = await prisma.favorite.findUnique({
    where: { userId_animeId: { userId: user.id, animeId } },
  });

  if (existing) {
    await prisma.favorite.delete({ where: { id: existing.id } });
    return NextResponse.json({ isFavorite: false });
  } else {
    await prisma.favorite.create({ data: { userId: user.id, animeId } });
    return NextResponse.json({ isFavorite: true });
  }
}

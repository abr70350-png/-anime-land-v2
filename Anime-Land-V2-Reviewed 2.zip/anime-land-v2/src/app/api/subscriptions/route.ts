import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'يرجى تسجيل الدخول لتفعيل الإشعارات' }, { status: 401 });

  const { animeId } = await req.json();
  const existing = await prisma.subscription.findUnique({
    where: { userId_animeId: { userId: user.id, animeId } },
  });

  if (existing) {
    await prisma.subscription.delete({ where: { id: existing.id } });
    return NextResponse.json({ isSubscribed: false });
  } else {
    await prisma.subscription.create({ data: { userId: user.id, animeId } });
    return NextResponse.json({ isSubscribed: true });
  }
}

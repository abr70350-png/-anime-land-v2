import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function GET() {
  const latestEpisodes = await prisma.episode.findMany({
    orderBy: { publishedAt: 'desc' },
    take: 12,
    include: {
      anime: {
        select: { slug: true, titleAr: true, titleEn: true, coverImage: true, ageRating: true },
      },
    },
  });
  return NextResponse.json({ episodes: latestEpisodes });
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user || user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'صلاحيات المشرف مطلوبة' }, { status: 403 });
  }

  try {
    const { animeId, seasonNumber, episodeNumber, titleAr, durationSec, thumbnailUrl, videoUrl1080, videoUrl720, videoUrl480 } =
      await req.json();

    const anime = await prisma.anime.findUnique({ where: { id: animeId } });
    if (!anime) {
      return NextResponse.json({ error: 'الأنمي غير موجود' }, { status: 404 });
    }

    const sources = JSON.stringify({
      '1080p': videoUrl1080,
      '720p': videoUrl720 || videoUrl1080,
      '480p': videoUrl480 || videoUrl720 || videoUrl1080,
    });

    const episode = await prisma.episode.create({
      data: {
        animeId,
        seasonNumber: Number(seasonNumber) || 1,
        episodeNumber: Number(episodeNumber),
        titleAr,
        durationSec: Number(durationSec) || 1440,
        thumbnailUrl: thumbnailUrl || anime.bannerImage,
        videoSources: sources,
      },
    });

    const subscribers = await prisma.subscription.findMany({ where: { animeId } });
    if (subscribers.length > 0) {
      await prisma.notification.createMany({
        data: subscribers.map((sub) => ({
          userId: sub.userId,
          title: `حلقة جديدة: ${anime.titleAr}`,
          message: `توفرت الآن الحلقة ${episode.episodeNumber} (${episode.titleAr}) للمشاهدة بجودة عالية.`,
          link: `/watch/${anime.slug}/${episode.id}`,
        })),
      });
    }

    return NextResponse.json({ episode }, { status: 201 });
  } catch (error) {
    console.error('Create episode error:', error);
    return NextResponse.json({ error: 'تعذر إضافة الحلقة (تأكد من عدم تكرار رقم الحلقة)' }, { status: 400 });
  }
}

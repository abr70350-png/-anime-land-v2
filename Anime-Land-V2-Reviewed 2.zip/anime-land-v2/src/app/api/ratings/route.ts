import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'يرجى تسجيل الدخول للتقييم' }, { status: 401 });

  const { animeId, score } = await req.json();
  const numScore = Number(score);
  if (numScore < 1 || numScore > 10) {
    return NextResponse.json({ error: 'التقييم يجب أن يكون بين 1 و 10' }, { status: 400 });
  }

  await prisma.rating.upsert({
    where: { userId_animeId: { userId: user.id, animeId } },
    update: { score: numScore },
    create: { userId: user.id, animeId, score: numScore },
  });

  const agg = await prisma.rating.aggregate({
    where: { animeId },
    _avg: { score: true },
    _count: { score: true },
  });

  const anime = await prisma.anime.findUnique({ where: { id: animeId } });
  const baseCount = anime?.ratingCount || 1;
  const baseAvg = anime?.avgRating || 8.5;
  const userCount = agg._count.score;
  const userSum = (agg._avg.score || numScore) * userCount;
  const newAvg = Number(((baseAvg * baseCount + userSum) / (baseCount + userCount)).toFixed(1));

  await prisma.anime.update({
    where: { id: animeId },
    data: { avgRating: newAvg },
  });

  return NextResponse.json({ userRating: numScore, avgRating: newAvg });
}

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ saved: false }, { status: 200 });

  const { episodeId, progressSeconds, durationSeconds } = await req.json();
  if (!episodeId || typeof progressSeconds !== 'number') {
    return NextResponse.json({ error: 'بيانات غير مكتملة' }, { status: 400 });
  }

  const dur = Math.max(1, Number(durationSeconds) || 1440);
  const completed = progressSeconds / dur >= 0.9;

  const record = await prisma.watchHistory.upsert({
    where: { userId_episodeId: { userId: user.id, episodeId } },
    update: {
      progressSeconds: Math.floor(progressSeconds),
      durationSeconds: Math.floor(dur),
      completed,
    },
    create: {
      userId: user.id,
      episodeId,
      progressSeconds: Math.floor(progressSeconds),
      durationSeconds: Math.floor(dur),
      completed,
    },
  });

  return NextResponse.json({ saved: true, record });
}

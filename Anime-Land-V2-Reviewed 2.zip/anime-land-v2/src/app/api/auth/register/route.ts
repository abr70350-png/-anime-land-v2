import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { signToken } from '@/lib/auth';

const registerSchema = z.object({
  username: z.string().min(3, 'اسم المستخدم يجب أن يكون 3 أحرف على الأقل').max(30),
  email: z.string().email('البريد الإلكتروني غير صالح'),
  password: z.string().min(6, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'),
  avatarUrl: z.string().url().optional().or(z.literal('')),
});

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const parsed = registerSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.errors[0].message }, { status: 400 });
    }

    const { username, email, password, avatarUrl } = parsed.data;

    const existing = await prisma.user.findFirst({
      where: { OR: [{ email: email.toLowerCase() }, { username }] },
    });
    if (existing) {
      return NextResponse.json({ error: 'البريد الإلكتروني أو اسم المستخدم مسجل مسبقاً' }, { status: 409 });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const user = await prisma.user.create({
      data: {
        username,
        email: email.toLowerCase(),
        passwordHash,
        avatarUrl: avatarUrl || 'https://s4.anilist.co/file/anilistcdn/character/large/b40-chQb5M8M38c1.png',
      },
      select: { id: true, username: true, email: true, avatarUrl: true, role: true, bio: true },
    });

    await prisma.notification.create({
      data: {
        userId: user.id,
        title: 'أهلاً بك في Anime Land',
        message: 'حسابك جاهز الآن! أضف أنمياتك المفضلة لتصلك إشعارات الحلقات الجديدة فور صدورها.',
        link: '/library',
      },
    });

    const token = await signToken({ userId: user.id, email: user.email, role: user.role });
    const res = NextResponse.json({ user }, { status: 201 });
    res.cookies.set('animeland_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 60 * 60 * 24 * 30,
    });
    return res;
  } catch (error) {
    console.error('Register error:', error);
    return NextResponse.json({ error: 'حدث خطأ أثناء إنشاء الحساب' }, { status: 500 });
  }
}

import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ user: null }, { status: 200 });
  }

  const [favorites, subscriptions, watchHistory, notifications] = await Promise.all([
    prisma.favorite.findMany({
      where: { userId: user.id },
      include: { anime: true },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.subscription.findMany({
      where: { userId: user.id },
      select: { animeId: true },
    }),
    prisma.watchHistory.findMany({
      where: { userId: user.id },
      include: { episode: { include: { anime: true } } },
      orderBy: { updatedAt: 'desc' },
      take: 20,
    }),
    prisma.notification.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 20,
    }),
  ]);

  return NextResponse.json({
    user,
    favorites: favorites.map((f) => f.anime),
    subscribedAnimeIds: subscriptions.map((s) => s.animeId),
    watchHistory,
    notifications,
  });
}

export async function PATCH(req: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
  }

  const { username, avatarUrl, bio } = await req.json();
  const updated = await prisma.user.update({
    where: { id: user.id },
    data: {
      ...(username ? { username } : {}),
      ...(avatarUrl ? { avatarUrl } : {}),
      ...(bio !== undefined ? { bio } : {}),
    },
    select: { id: true, username: true, email: true, avatarUrl: true, role: true, bio: true },
  });

  return NextResponse.json({ user: updated });
}

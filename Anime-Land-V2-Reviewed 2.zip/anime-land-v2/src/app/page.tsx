import React from 'react';
import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import AnimeCard from '@/components/AnimeCard';
import {
  Flame,
  Sparkles,
  Calendar,
  Star,
  PlayCircle,
  Compass,
  Clock,
  ShieldCheck,
} from 'lucide-react';

export const dynamic = 'force-dynamic';

export default async function HomePage() {
  const [mostWatched, newestAnimes, seasonalAnimes, topRated, latestEpisodes, recommended] =
    await Promise.all([
      prisma.anime.findMany({ orderBy: { viewsCount: 'desc' }, take: 6 }),
      prisma.anime.findMany({ orderBy: { releaseYear: 'desc' }, take: 6 }),
      prisma.anime.findMany({ where: { status: 'مستمر' }, orderBy: { avgRating: 'desc' }, take: 6 }),
      prisma.anime.findMany({ orderBy: { avgRating: 'desc' }, take: 6 }),
      prisma.episode.findMany({
        orderBy: { publishedAt: 'desc' },
        take: 6,
        include: { anime: true },
      }),
      prisma.anime.findMany({ where: { isTrending: true }, take: 6 }),
    ]);

  const featured = mostWatched[0];

  return (
    <div className="space-y-12 pb-8">
      {featured && (
        <section className="relative h-[440px] md:h-[520px] w-full overflow-hidden">
          <img
            src={featured.bannerImage || featured.coverImage}
            alt={featured.titleAr}
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-50 via-slate-900/70 to-black/40 dark:from-brand-bg dark:via-brand-bg/75 dark:to-black/30" />
          <div className="absolute inset-0 bg-gradient-to-l from-black/80 via-black/40 to-transparent" />

          <div className="absolute inset-0 max-w-7xl mx-auto px-4 flex flex-col justify-end pb-10 md:pb-14">
            <div className="max-w-2xl space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-3 py-1 rounded-full bg-brand-primary text-white text-xs font-bold flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5" />
                  الأكثر رواجاً الآن
                </span>
                <span className="px-2.5 py-1 rounded-full bg-white/15 backdrop-blur-md text-white text-xs font-semibold">
                  {featured.releaseYear} • {featured.ageRating}
                </span>
                <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  {featured.avgRating}
                </span>
              </div>

              <h1 className="text-3xl md:text-5xl font-extrabold text-white leading-tight">
                {featured.titleAr}
              </h1>
              <p className="text-sm text-slate-300 font-medium">{featured.titleEn}</p>
              <p className="text-sm md:text-base text-slate-200 line-clamp-3 leading-relaxed">
                {featured.synopsisAr}
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <Link
                  href={`/anime/${featured.slug}`}
                  className="px-6 py-3 rounded-xl bg-brand-primary hover:bg-brand-primaryHover text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-brand-primary/30 transition"
                >
                  <PlayCircle className="w-5 h-5" />
                  <span>مشاهدة الآن</span>
                </Link>
                <Link
                  href="/library"
                  className="px-5 py-3 rounded-xl bg-white/15 hover:bg-white/25 backdrop-blur-md text-white font-bold text-sm flex items-center gap-2 transition"
                >
                  <Compass className="w-4 h-4" />
                  <span>تصفح المكتبة</span>
                </Link>
              </div>
            </div>
          </div>
        </section>
      )}

      <div className="max-w-7xl mx-auto px-4 space-y-12">
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl md:text-2xl font-extrabold flex items-center gap-2">
              <Clock className="w-6 h-6 text-brand-accent" />
              <span>آخر الحلقات المضافة</span>
            </h2>
            <span className="text-xs text-emerald-500 font-bold flex items-center gap-1">
              <ShieldCheck className="w-4 h-4" />
              مصادر مرخصة
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {latestEpisodes.map((ep) => (
              <Link
                key={ep.id}
                href={`/watch/${ep.anime.slug}/${ep.id}`}
                className="group flex items-center gap-3.5 p-3 rounded-2xl bg-white dark:bg-brand-card border border-slate-200 dark:border-brand-border hover:border-brand-primary transition"
              >
                <div className="relative w-28 h-20 rounded-xl overflow-hidden shrink-0 bg-slate-900">
                  <img
                    src={ep.thumbnailUrl}
                    alt={ep.titleAr}
                    className="w-full h-full object-cover group-hover:scale-105 transition"
                  />
                  <div className="absolute inset-0 bg-black/35 flex items-center justify-center">
                    <PlayCircle className="w-7 h-7 text-white" />
                  </div>
                </div>
                <div className="min-w-0 flex-1 space-y-1">
                  <span className="inline-block px-2 py-0.5 rounded bg-brand-primary/15 text-brand-primary text-[11px] font-bold">
                    الحلقة {ep.episodeNumber}
                  </span>
                  <h3 className="font-bold text-sm truncate group-hover:text-brand-primary transition">
                    {ep.anime.titleAr}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{ep.titleAr}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl md:text-2xl font-extrabold flex items-center gap-2">
              <Flame className="w-6 h-6 text-orange-500" />
              <span>الأنميات الأكثر مشاهدة</span>
            </h2>
            <Link href="/library?sort=popular" className="text-xs font-bold text-brand-primary hover:underline">
              عرض الكل ←
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {mostWatched.map((anime) => (
              <AnimeCard key={anime.id} anime={anime} />
            ))}
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl md:text-2xl font-extrabold flex items-center gap-2">
              <Calendar className="w-6 h-6 text-emerald-500" />
              <span>الأنميات الموسمية (تُعرض حالياً)</span>
            </h2>
            <Link href="/library?status=مستمر" className="text-xs font-bold text-brand-primary hover:underline">
              عرض الكل ←
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {seasonalAnimes.map((anime) => (
              <AnimeCard key={anime.id} anime={anime} />
            ))}
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl md:text-2xl font-extrabold flex items-center gap-2">
              <Star className="w-6 h-6 text-amber-400 fill-amber-400" />
              <span>الأنميات الأكثر تقييماً</span>
            </h2>
            <Link href="/library?sort=rating" className="text-xs font-bold text-brand-primary hover:underline">
              عرض الكل ←
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {topRated.map((anime) => (
              <AnimeCard key={anime.id} anime={anime} />
            ))}
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl md:text-2xl font-extrabold flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-brand-primary" />
              <span>الأنميات الجديدة ومقترحات لك</span>
            </h2>
            <Link href="/library?sort=newest" className="text-xs font-bold text-brand-primary hover:underline">
              استكشف المزيد ←
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {(recommended.length ? recommended : newestAnimes).map((anime) => (
              <AnimeCard key={anime.id} anime={anime} />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

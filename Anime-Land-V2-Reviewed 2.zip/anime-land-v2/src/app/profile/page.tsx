'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useApp } from '@/context/AppContext';
import AnimeCard from '@/components/AnimeCard';
import { Heart, History, LogOut, Save, PlayCircle, ShieldCheck } from 'lucide-react';

export default function ProfilePage() {
  const router = useRouter();
  const { user, favorites, watchHistory, loadingAuth, logout, refreshUserData } = useApp();
  const [tab, setTab] = useState<'favorites' | 'history' | 'settings'>('favorites');
  const [username, setUsername] = useState(user?.username || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [avatarUrl, setAvatarUrl] = useState(user?.avatarUrl || '');
  const [saving, setSaving] = useState(false);

  if (loadingAuth) return <div className="p-12 text-center">جاري تحميل الملف الشخصي...</div>;

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center space-y-4">
        <h1 className="text-xl font-extrabold">يرجى تسجيل الدخول لعرض ملفك الشخصي</h1>
        <Link
          href="/auth"
          className="inline-block px-6 py-3 rounded-xl bg-brand-primary text-white text-sm font-bold"
        >
          الانتقال لتسجيل الدخول
        </Link>
      </div>
    );
  }

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    await fetch('/api/auth/me', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: username || user.username,
        bio,
        avatarUrl: avatarUrl || user.avatarUrl,
      }),
    });
    await refreshUserData();
    setSaving(false);
    alert('تم تحديث بيانات ملفك الشخصي بنجاح');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      <div className="bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border rounded-3xl p-6 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-right">
          <img
            src={user.avatarUrl}
            alt={user.username}
            className="w-20 h-20 rounded-2xl object-cover border-2 border-brand-primary"
          />
          <div>
            <div className="flex items-center justify-center sm:justify-start gap-2">
              <h1 className="text-2xl font-extrabold">{user.username}</h1>
              {user.role === 'ADMIN' && (
                <span className="px-2.5 py-0.5 rounded-lg bg-brand-primary/20 text-brand-primary text-xs font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> مشرف
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">{user.email}</p>
            <p className="text-sm text-slate-600 dark:text-slate-300 mt-2">{user.bio}</p>
          </div>
        </div>

        <button
          onClick={async () => {
            await logout();
            router.push('/');
          }}
          className="px-4 py-2.5 rounded-xl bg-rose-500/15 text-rose-500 hover:bg-rose-500 hover:text-white text-xs font-bold flex items-center gap-1.5 transition"
        >
          <LogOut className="w-4 h-4" />
          <span>تسجيل الخروج</span>
        </button>
      </div>

      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-brand-border pb-3">
        <button
          onClick={() => setTab('favorites')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 ${
            tab === 'favorites' ? 'bg-brand-primary text-white' : 'bg-white dark:bg-brand-surface'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>المفضلة ({favorites.length})</span>
        </button>
        <button
          onClick={() => setTab('history')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 ${
            tab === 'history' ? 'bg-brand-primary text-white' : 'bg-white dark:bg-brand-surface'
          }`}
        >
          <History className="w-4 h-4" />
          <span>سجل المشاهدة ({watchHistory.length})</span>
        </button>
        <button
          onClick={() => {
            setUsername(user.username);
            setBio(user.bio || '');
            setAvatarUrl(user.avatarUrl);
            setTab('settings');
          }}
          className={`px-4 py-2 rounded-xl text-xs font-bold ${
            tab === 'settings' ? 'bg-brand-primary text-white' : 'bg-white dark:bg-brand-surface'
          }`}
        >
          تعديل الملف
        </button>
      </div>

      {tab === 'favorites' && (
        <div>
          {favorites.length === 0 ? (
            <p className="text-center py-12 text-slate-400 text-sm">قائمة المفضلة فارغة حالياً.</p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {favorites.map((anime) => (
                <AnimeCard key={anime.id} anime={anime} />
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'history' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {watchHistory.length === 0 ? (
            <p className="text-center py-12 text-slate-400 text-sm col-span-2">لم تشاهد أي حلقة بعد.</p>
          ) : (
            watchHistory.map((item) => {
              const pct = Math.min(100, Math.round((item.progressSeconds / item.durationSeconds) * 100));
              return (
                <Link
                  key={item.id}
                  href={`/watch/${item.episode.anime.slug}/${item.episode.id}`}
                  className="flex items-center gap-4 p-3.5 rounded-2xl bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border hover:border-brand-primary transition"
                >
                  <img
                    src={item.episode.thumbnailUrl}
                    alt={item.episode.titleAr}
                    className="w-28 h-18 rounded-xl object-cover"
                  />
                  <div className="flex-1 min-w-0 space-y-1.5">
                    <h3 className="font-bold text-sm truncate">{item.episode.anime.titleAr}</h3>
                    <p className="text-xs text-slate-400 truncate">
                      الحلقة {item.episode.episodeNumber}: {item.episode.titleAr}
                    </p>
                    <div className="w-full h-1.5 bg-slate-200 dark:bg-brand-card rounded-full overflow-hidden">
                      <div className="h-full bg-brand-primary" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                  <PlayCircle className="w-6 h-6 text-brand-primary shrink-0" />
                </Link>
              );
            })
          )}
        </div>
      )}

      {tab === 'settings' && (
        <form
          onSubmit={handleSaveProfile}
          className="max-w-lg bg-white dark:bg-brand-surface p-6 rounded-2xl border border-slate-200 dark:border-brand-border space-y-4"
        >
          <div className="space-y-1">
            <label className="text-xs font-bold">اسم المستخدم</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-sm"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold">رابط الصورة الشخصية</label>
            <input
              type="url"
              value={avatarUrl}
              onChange={(e) => setAvatarUrl(e.target.value)}
              className="w-full bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-sm"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold">النبذة الشخصية</label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={3}
              className="w-full bg-slate-100 dark:bg-brand-card border border-brand-border rounded-xl p-2.5 text-sm"
            />
          </div>
          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2.5 rounded-xl bg-brand-primary text-white text-xs font-bold flex items-center gap-1.5"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'جاري الحفظ...' : 'حفظ التغييرات'}</span>
          </button>
        </form>
      )}
    </div>
  );
}

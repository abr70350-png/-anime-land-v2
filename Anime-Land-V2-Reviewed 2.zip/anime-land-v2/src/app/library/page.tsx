'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import AnimeCard, { AnimeCardData } from '@/components/AnimeCard';
import { Search, SlidersHorizontal, RotateCcw } from 'lucide-react';

const GENRES = ['الكل', 'أكشن', 'مغامرات', 'غموض', 'رياضة', 'كوميديا', 'رومانسي', 'دراما', 'فانتازيا'];
const STATUSES = ['الكل', 'مستمر', 'مكتمل'];
const YEARS = ['الكل', '2026', '2024', '2023', '2022', '2020', '2016', '2014', '2011'];

function LibraryContent() {
  const searchParams = useSearchParams();
  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [genre, setGenre] = useState(searchParams.get('genre') || 'الكل');
  const [status, setStatus] = useState(searchParams.get('status') || 'الكل');
  const [year, setYear] = useState(searchParams.get('year') || 'الكل');
  const [minRating, setMinRating] = useState(searchParams.get('minRating') || '0');
  const [sort, setSort] = useState(searchParams.get('sort') || 'popular');

  const [animes, setAnimes] = useState<AnimeCardData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const controller = new AbortController();
    const fetchAnimes = async () => {
      setLoading(true);
      try {
        const params = new URLSearchParams();
        if (query) params.set('q', query);
        if (genre !== 'الكل') params.set('genre', genre);
        if (status !== 'الكل') params.set('status', status);
        if (year !== 'الكل') params.set('year', year);
        if (minRating !== '0') params.set('minRating', minRating);
        if (sort) params.set('sort', sort);

        const res = await fetch(`/api/anime?${params.toString()}`, { signal: controller.signal });
        const data = await res.json();
        setAnimes(data.animes || []);
      } catch (err: any) {
        if (err.name !== 'AbortError') console.error(err);
      } finally {
        setLoading(false);
      }
    };

    const timer = setTimeout(fetchAnimes, 200);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [query, genre, status, year, minRating, sort]);

  const resetFilters = () => {
    setQuery('');
    setGenre('الكل');
    setStatus('الكل');
    setYear('الكل');
    setMinRating('0');
    setSort('popular');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold">مكتبة الأنمي الشاملة</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            ابحث بالاسم العربي، الإنجليزي، أو الياباني وفلتر النتائج بدقة
          </p>
        </div>

        <button
          onClick={resetFilters}
          className="self-start flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-200 dark:bg-brand-surface text-xs font-bold hover:bg-brand-primary hover:text-white transition"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>إعادة ضبط الفلاتر</span>
        </button>
      </div>

      <div className="relative">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="اكتب اسم الأنمي بالعربي (مثال: القناص)، الإنجليزي (Hunter)، أو الياباني (憂国のモリアーティ)..."
          className="w-full bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border rounded-2xl py-3.5 pr-12 pl-4 text-sm focus:outline-none focus:border-brand-primary shadow-sm"
        />
        <Search className="w-5 h-5 text-slate-400 absolute right-4 top-1/2 -translate-y-1/2" />
      </div>

      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        {GENRES.map((g) => (
          <button
            key={g}
            onClick={() => setGenre(g)}
            className={`px-4 py-2 rounded-xl text-xs font-bold shrink-0 transition ${
              genre === g
                ? 'bg-brand-primary text-white shadow-md shadow-brand-primary/25'
                : 'bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border hover:border-brand-primary'
            }`}
          >
            {g}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-white dark:bg-brand-surface p-4 rounded-2xl border border-slate-200 dark:border-brand-border">
        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-400 flex items-center gap-1">
            <SlidersHorizontal className="w-3 h-3" /> الحالة
          </label>
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="w-full bg-slate-100 dark:bg-brand-card border border-slate-200 dark:border-brand-border rounded-xl px-3 py-2 text-xs font-bold"
          >
            {STATUSES.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>

        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-400">سنة الإصدار</label>
          <select
            value={year}
            onChange={(e) => setYear(e.target.value)}
            className="w-full bg-slate-100 dark:bg-brand-card border border-slate-200 dark:border-brand-border rounded-xl px-3 py-2 text-xs font-bold"
          >
            {YEARS.map((y) => (
              <option key={y} value={y}>{y}</option>
            ))}
          </select>
        </div>

        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-400">الحد الأدنى للتقييم</label>
          <select
            value={minRating}
            onChange={(e) => setMinRating(e.target.value)}
            className="w-full bg-slate-100 dark:bg-brand-card border border-slate-200 dark:border-brand-border rounded-xl px-3 py-2 text-xs font-bold"
          >
            <option value="0">جميع التقييمات</option>
            <option value="9">9.0 فأعلى</option>
            <option value="8.5">8.5 فأعلى</option>
            <option value="8">8.0 فأعلى</option>
          </select>
        </div>

        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-400">ترتيب حسب</label>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="w-full bg-slate-100 dark:bg-brand-card border border-slate-200 dark:border-brand-border rounded-xl px-3 py-2 text-xs font-bold"
          >
            <option value="popular">الأكثر مشاهدة</option>
            <option value="rating">الأعلى تقييماً</option>
            <option value="newest">الأحدث إصداراً</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {[...Array(6)].map((_, idx) => (
            <div key={idx} className="aspect-[2/3] rounded-2xl bg-slate-200 dark:bg-brand-card animate-pulse" />
          ))}
        </div>
      ) : animes.length === 0 ? (
        <div className="text-center py-16 bg-white dark:bg-brand-surface rounded-2xl border border-slate-200 dark:border-brand-border">
          <p className="text-lg font-bold">لا توجد نتائج مطابقة لبحثك</p>
          <p className="text-xs text-slate-400 mt-1">جرب تغيير كلمات البحث أو إزالة بعض الفلاتر</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {animes.map((anime) => (
            <AnimeCard key={anime.id} anime={anime} />
          ))}
        </div>
      )}
    </div>
  );
}

export default function LibraryPage() {
  return (
    <Suspense fallback={<div className="p-10 text-center">جاري تحميل المكتبة...</div>}>
      <LibraryContent />
    </Suspense>
  );
}

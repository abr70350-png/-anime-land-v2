'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import VideoPlayer from '@/components/VideoPlayer';
import { ArrowRight, Play, Flag } from 'lucide-react';
import { useApp } from '@/context/AppContext';

export default function WatchEpisodePage() {
  const params = useParams();
  const router = useRouter();
  const slug = params.slug as string;
  const episodeId = params.episodeId as string;
  const { user } = useApp();

  const [anime, setAnime] = useState<any>(null);
  const [userState, setUserState] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/anime/${slug}`)
      .then((res) => res.json())
      .then((data) => {
        setAnime(data.anime);
        setUserState(data.userState);
      })
      .finally(() => setLoading(false));
  }, [slug]);

  if (loading) return <div className="p-12 text-center">جاري تجهيز مشغل الفيديو المرخص...</div>;
  if (!anime) return <div className="p-12 text-center font-bold">الأنمي غير موجود</div>;

  const episodes = anime.episodes || [];
  const currentIndex = episodes.findIndex((e: any) => e.id === episodeId);
  const currentEpisode = episodes[currentIndex];

  if (!currentEpisode) {
    return <div className="p-12 text-center font-bold">الحلقة غير متوفرة</div>;
  }

  let parsedSources: Record<string, string> = {};
  try {
    parsedSources = JSON.parse(currentEpisode.videoSources);
  } catch {
    parsedSources = { '720p': currentEpisode.videoSources };
  }

  const initialProgress = userState?.watchProgress?.[currentEpisode.id]?.progressSeconds || 0;
  const prevEp = currentIndex > 0 ? episodes[currentIndex - 1] : null;
  const nextEp = currentIndex < episodes.length - 1 ? episodes[currentIndex + 1] : null;

  const handleReportEpisode = async () => {
    if (!user) return router.push('/auth');
    await fetch('/api/reports', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        targetType: 'EPISODE',
        targetId: currentEpisode.id,
        reason: 'مشكلة تشغيل في الحلقة',
      }),
    });
    alert('تم إرسال بلاغك لفريق الدعم الفني.');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <Link
          href={`/anime/${anime.slug}`}
          className="inline-flex items-center gap-2 text-sm font-bold text-brand-primary hover:underline"
        >
          <ArrowRight className="w-4 h-4" />
          <span>العودة لصفحة {anime.titleAr}</span>
        </Link>

        <button
          onClick={handleReportEpisode}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border text-xs font-bold text-rose-500"
        >
          <Flag className="w-3.5 h-3.5" />
          <span>إبلاغ عن عطل</span>
        </button>
      </div>

      <VideoPlayer
        episodeId={currentEpisode.id}
        titleAr={currentEpisode.titleAr}
        episodeNumber={currentEpisode.episodeNumber}
        videoSources={parsedSources}
        licenseProvider={currentEpisode.licenseProvider}
        initialProgress={initialProgress}
        hasPrev={Boolean(prevEp)}
        hasNext={Boolean(nextEp)}
        onPrev={() => prevEp && router.push(`/watch/${anime.slug}/${prevEp.id}`)}
        onNext={() => nextEp && router.push(`/watch/${anime.slug}/${nextEp.id}`)}
      />

      <div className="bg-white dark:bg-brand-surface p-5 rounded-2xl border border-slate-200 dark:border-brand-border flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-brand-primary">
            الموسم {currentEpisode.seasonNumber} • الحلقة {currentEpisode.episodeNumber}
          </span>
          <h1 className="text-xl font-extrabold mt-0.5">{currentEpisode.titleAr}</h1>
          <p className="text-xs text-slate-400 mt-1">
            {user
              ? 'يتم حفظ نقطة توقفك تلقائياً في سجل المشاهدة الخاص بحسابك.'
              : 'سجّل الدخول لحفظ آخر نقطة مشاهدة تلقائياً.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {prevEp && (
            <Link
              href={`/watch/${anime.slug}/${prevEp.id}`}
              className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-brand-card text-xs font-bold hover:border-brand-primary border border-transparent transition"
            >
              الحلقة السابقة ({prevEp.episodeNumber})
            </Link>
          )}
          {nextEp && (
            <Link
              href={`/watch/${anime.slug}/${nextEp.id}`}
              className="px-4 py-2.5 rounded-xl bg-brand-primary text-white text-xs font-bold hover:bg-brand-primaryHover transition"
            >
              الحلقة التالية ({nextEp.episodeNumber})
            </Link>
          )}
        </div>
      </div>

      <div className="space-y-3">
        <h2 className="text-lg font-extrabold">جميع حلقات {anime.titleAr}</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2.5">
          {episodes.map((ep: any) => {
            const active = ep.id === currentEpisode.id;
            return (
              <Link
                key={ep.id}
                href={`/watch/${anime.slug}/${ep.id}`}
                className={`p-3 rounded-xl border text-center transition ${
                  active
                    ? 'bg-brand-primary text-white border-brand-primary font-extrabold shadow-md'
                    : 'bg-white dark:bg-brand-surface border-slate-200 dark:border-brand-border hover:border-brand-primary font-bold'
                }`}
              >
                <div className="flex items-center justify-center gap-1 text-xs">
                  {active && <Play className="w-3 h-3 fill-white" />}
                  <span>حلقة {ep.episodeNumber}</span>
                </div>
                <p className="text-[11px] opacity-80 truncate mt-1">{ep.titleAr}</p>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}

'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useApp } from '@/context/AppContext';
import { Sparkles, Mail, Lock, User, Image as ImageIcon } from 'lucide-react';

const AVATAR_PRESETS = [
  'https://s4.anilist.co/file/anilistcdn/character/large/b13701-565224242.png',
  'https://s4.anilist.co/file/anilistcdn/character/large/b40-chQb5M8M38c1.png',
  'https://s4.anilist.co/file/anilistcdn/character/large/b30-2854192.png',
  'https://s4.anilist.co/file/anilistcdn/character/large/b176754-PC123.png',
];

export default function AuthPage() {
  const router = useRouter();
  const { refreshUserData } = useApp();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [avatarUrl, setAvatarUrl] = useState(AVATAR_PRESETS[0]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const endpoint = mode === 'login' ? '/api/auth/login' : '/api/auth/register';
      const payload =
        mode === 'login' ? { email, password } : { username, email, password, avatarUrl };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'حدث خطأ غير متوقع');
      } else {
        await refreshUserData();
        router.push('/');
      }
    } catch {
      setError('تعذر الاتصال بالخادم');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-12">
      <div className="bg-white dark:bg-brand-surface border border-slate-200 dark:border-brand-border rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-brand-primary to-brand-accent mx-auto flex items-center justify-center text-white">
            <Sparkles className="w-6 h-6" />
          </div>
          <h1 className="text-2xl font-extrabold">
            {mode === 'login' ? 'تسجيل الدخول إلى Anime Land' : 'إنشاء حساب جديد'}
          </h1>
          <p className="text-xs text-slate-400">
            احفظ مفضلتك، تابع سجل مشاهدتك، واحصل على إشعارات الحلقات الجديدة
          </p>
        </div>

        <div className="grid grid-cols-2 p-1 rounded-xl bg-slate-100 dark:bg-brand-card">
          <button
            type="button"
            onClick={() => setMode('login')}
            className={`py-2 rounded-lg text-xs font-bold transition ${
              mode === 'login' ? 'bg-brand-primary text-white' : 'text-slate-400'
            }`}
          >
            تسجيل الدخول
          </button>
          <button
            type="button"
            onClick={() => setMode('register')}
            className={`py-2 rounded-lg text-xs font-bold transition ${
              mode === 'register' ? 'bg-brand-primary text-white' : 'text-slate-400'
            }`}
          >
            حساب جديد
          </button>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-500 text-xs font-bold text-center">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'register' && (
            <>
              <div className="space-y-1">
                <label className="text-xs font-bold">اسم المستخدم</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="مثال: عاشق_الأنمي"
                    className="w-full bg-slate-100 dark:bg-brand-card border border-slate-200 dark:border-brand-border rounded-xl py-2.5 pr-10 pl-3 text-sm"
                  />
                  <User className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold flex items-center gap-1">
                  <ImageIcon className="w-3.5 h-3.5" /> اختر صورتك الشخصية
                </label>
                <div className="flex items-center gap-3">
                  {AVATAR_PRESETS.map((url) => (
                    <button
                      type="button"
                      key={url}
                      onClick={() => setAvatarUrl(url)}
                      className={`w-12 h-12 rounded-xl overflow-hidden border-2 transition ${
                        avatarUrl === url ? 'border-brand-primary scale-105' : 'border-transparent opacity-60'
                      }`}
                    >
                      <img src={url} alt="avatar" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

          <div className="space-y-1">
            <label className="text-xs font-bold">البريد الإلكتروني</label>
            <div className="relative">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full bg-slate-100 dark:bg-brand-card border border-slate-200 dark:border-brand-border rounded-xl py-2.5 pr-10 pl-3 text-sm"
              />
              <Mail className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold">كلمة المرور</label>
            <div className="relative">
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-slate-100 dark:bg-brand-card border border-slate-200 dark:border-brand-border rounded-xl py-2.5 pr-10 pl-3 text-sm"
              />
              <Lock className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-brand-primary hover:bg-brand-primaryHover text-white font-bold text-sm shadow-lg shadow-brand-primary/25 transition"
          >
            {loading ? 'جاري المعالجة...' : mode === 'login' ? 'دخول' : 'إنشاء الحساب'}
          </button>
        </form>
      </div>
    </div>
  );
}

import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";
dotenv.config();

const app = express();
app.use(express.json({limit:"25mb"}));
app.use(express.static("public"));

const client = process.env.OPENAI_API_KEY ? new OpenAI({apiKey:process.env.OPENAI_API_KEY}) : null;

const SYSTEM = `أنت AnimeGPT Pro، مساعد عربي محترف لصناعة الأنمي والمانجا.
تساعد في تطوير الفكرة والعالم والشخصيات والحبكة والسيناريو ولوحات المشاهد ووصف الصور والفيديو.
عند وجود بطاقة شخصية ثابتة، التزم حرفيًا بملامحها وملابسها وألوانها وعمرها الظاهري وسماتها البصرية ولا تغيّرها بين المشاهد.
فرّق بين ما تم توليده فعليًا وما هو مجرد نص أو خطة. لا تدّعِ إنشاء فيديو إذا لم يرجع ملف فيديو فعلي.`;

app.get("/api/status", (_req,res) => res.json({
  chat:!!client, images:!!client,
  video:!!(process.env.VIDEO_API_BASE_URL && process.env.VIDEO_API_KEY && process.env.VIDEO_MODEL)
}));

app.post("/api/chat", async (req,res) => {
  try {
    if (!client) return res.status(503).json({error:"المحادثة تحتاج OPENAI_API_KEY في إعدادات الخادم."});
    const messages = Array.isArray(req.body.messages) ? req.body.messages.slice(-24) : [];
    const input = messages.map(m=>({role:m.role==="assistant"?"assistant":"user",content:String(m.content||"")}));
    const result = await client.responses.create({
      model:process.env.OPENAI_TEXT_MODEL || "gpt-6",
      instructions:SYSTEM,
      input
    });
    res.json({text:result.output_text || "لم يصل نص من النموذج."});
  } catch(e) { res.status(500).json({error:e.message || "تعذر إكمال الطلب."}); }
});

app.post("/api/image", async (req,res) => {
  try {
    if (!client) return res.status(503).json({error:"توليد الصور يحتاج OPENAI_API_KEY في إعدادات الخادم."});
    const {prompt, characterBible="", scene="", size="1024x1024"} = req.body || {};
    if (!String(prompt||"").trim()) return res.status(400).json({error:"اكتب وصف الصورة."});
    const fullPrompt = `Create a polished original anime production image. ${prompt}
Character continuity bible (must follow exactly): ${characterBible}
Scene details: ${scene}
Keep the same face, hairstyle, eye color, body proportions, outfit design and palette specified in the bible. Do not redesign the character. No captions, no watermark.`;
    const result = await client.images.generate({
      model:process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-flare",
      prompt:fullPrompt,
      size:["1024x1024","1024x1536","1536x1024"].includes(size)?size:"1024x1024",
      quality:"high"
    });
    const b64 = result.data?.[0]?.b64_json;
    if (!b64) return res.status(502).json({error:"لم يرجع مزود الصور بيانات صورة."});
    res.json({b64, mime:"image/png"});
  } catch(e) { res.status(500).json({error:e.message || "فشل توليد الصورة."}); }
});

// Generic video adapter. Uses a configurable third-party provider; no provider key is exposed to the browser.
app.post("/api/video", async (req,res) => {
  try {
    const {prompt, characterBible="", seconds="5", referenceImage=""} = req.body || {};
    if (!process.env.VIDEO_API_BASE_URL || !process.env.VIDEO_API_KEY || !process.env.VIDEO_MODEL) {
      return res.status(503).json({error:"محرك الفيديو غير مفعّل: يلزم اختيار مزود فيديو متاح حاليًا وإضافة عنوانه ومفتاحه ونموذجه في إعدادات الخادم."});
    }
    const base = process.env.VIDEO_API_BASE_URL.replace(/\/+$/,"");
    const payload = {
      model:process.env.VIDEO_MODEL,
      prompt:`Original anime video shot. ${prompt}\nCharacter continuity: ${characterBible}\nPreserve the exact character design, costume, colors and proportions. One coherent camera setup and one clear action.`,
      seconds:String(seconds)
    };
    if (referenceImage) payload.input_reference = referenceImage;
    const r = await fetch(base + "/videos", {
      method:"POST",
      headers:{"Authorization":`Bearer ${process.env.VIDEO_API_KEY}`,"Content-Type":"application/json"},
      body:JSON.stringify(payload)
    });
    const data = await r.json().catch(()=>({}));
    if (!r.ok) return res.status(r.status).json({error:data.error?.message || data.message || "رفض مزود الفيديو الطلب."});
    res.json({job:data, message:"تم إرسال طلب الفيديو إلى مزود الخدمة. حالة المهمة متاحة أدناه."});
  } catch(e) { res.status(500).json({error:e.message || "تعذر إرسال طلب الفيديو."}); }
});

app.get("/api/video/:id", async (req,res) => {
  try {
    if (!process.env.VIDEO_API_BASE_URL || !process.env.VIDEO_API_KEY) return res.status(503).json({error:"محرك الفيديو غير مربوط."});
    const base = process.env.VIDEO_API_BASE_URL.replace(/\/+$/,"");
    const r = await fetch(`${base}/videos/${encodeURIComponent(req.params.id)}`, {
      headers:{"Authorization":`Bearer ${process.env.VIDEO_API_KEY}`}
    });
    const data = await r.json().catch(()=>({}));
    res.status(r.status).json(data);
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.get("*", (_req,res)=>res.sendFile(process.cwd()+"/public/index.html"));
const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`AnimeGPT Pro listening on ${port}`));
